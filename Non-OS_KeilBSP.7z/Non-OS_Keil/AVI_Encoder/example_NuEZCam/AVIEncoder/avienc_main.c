#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wbio.h"
#include "wblib.h"
#include "w55fa93_reg.h"
#include "w55fa93_sic.h"
#include "demo.h"
#include "jpegcodec.h"
#include "W55FA93_VideoIn.h"
#include "AviLib.h"
#include "nvtfat.h"
#include "usbd.h"
#include "videoclass.h"

#define PCM					0
#define IMAADPCM			1


#define TIME_NO			120

extern int WITHOUT_AUDIO_TIME;
extern BOOL bVideo_Only;

extern int InitializeUAC(UINT32 u32SampleRate);
extern void StartUAC(void);
extern void StopUAC(void);
extern int GetPCMSampleData(PINT16 pi16PCM, INT32 u32SampleCount);
extern void Send_AudioOneMSPacket(PUINT32 pu32Address, PUINT32 pu32Length);

void JpegEncoderCallback(UINT32 u32ImageSize);
void jpegPre(void);

void uvcdEvent(void);

#define UVC_SKIP_FRAME		0

INT GetImageBuffer(void);
void ChangeFrame(BOOL bChangeSize, UINT32 u32Address, UINT16 u16Width,UINT16 u16Height);
INT GetImage(PUINT32 pu32Addr, PUINT32 pu32transferSize);
UINT32 ProcessUnitControl(UINT32 u32ItemSelect,UINT32 u32Value);

volatile INT32 i32CurTimer;

UINT32 volatile skey;

/* Buffer for Packet & Planar format */
UINT8 __align(32) u8FrameBuffer0[1280*720*2]; 	
UINT8 __align(32) u8FrameBuffer1[1280*720*2];




UINT8 __align(32) u8BitstreamBuffer0[MAX_JPEG_SIZE*JPEG_BUFFERNO]; 
//UINT32 u8BitstreamBuffer0; //[MAX_JPEG_SIZE*JPEG_BUFFERNO]; 
UINT8 __align(32) g_pbySnapBuffer[2]; //[0x20000];

UINT8 __align(32) g_ZeroBuffer[16]; 


UINT32  volatile BufStatus[ENCODE_BUFFERNO];   // 0 is empty, 1 is full, 2 is processing.
UINT32 volatile jpeg_mid, jpeg_out,jpeg_in, jpeg_final;  
UINT32  volatile vid_in, vid_out; 

UINT32  volatile JpegStatus[JPEG_BUFFERNO];   // 0 is empty, 1 is full, 2 is processing.

UINT32 volatile u32PacketFrameBuffer0, u32PacketFrameBuffer1;
UINT32 volatile u32BitstreamBuffer0,u32BitstreamBuffer1;

/* Current Buffer Address for JPEG Encode */
UINT32 volatile u32CurBitstreamAddress[JPEG_BUFFERNO];
UINT32 volatile u32JPEGSize[JPEG_BUFFERNO];
UINT32  volatile EncodeStatus[JPEG_BUFFERNO];   // 0 is empty, 1 is full, 2 is processing.

void AVIEncEvent(void);

/* Current Width & Height */
extern UINT16 u16CurWidth, u16CurHeight;
//UINT16 u16CurWidth = 640, u16CurHeight = 480;
//INT32	s_i32FrameRate = 30;  //30
extern INT32	s_i32FrameRate;  //30
INT32   s_i32Type = PCM; //IMAADPCM;   // PCM
INT32   s_i32SampleRate = 16000;
/* audio buffer */

MV_CFG_T tMvCfg;
INT16 *g_i16RecBuf;
INT32 g_i32RecSize;

extern INT16 *g_pi16AudioBuf;
extern int IN_DATA_BUF_NUM;
extern INT32 s_i16RecInSample;
extern INT32 s_i16RecOutPos;
extern UINT8 bPlaying;

extern int sCurNo;

int volatile   g_runavi=0;
INT volatile last_time;
int volatile last_vid_frame;
CHAR	g_suRecorderFile[40];	

UINT32 u32VideoInIdx;

// JPEG quantitation table
UINT8      g_au8QTableUser0[64], g_au8QTableUser1[64];

UINT8      g_au8QTableStd0[64] = {16,  11,  10,  16,  24,  40,  51,  61,
                                                        12,  12,  14,  19,  26,  58,  60,  55,
                                                        14,  13,  16,  24,  40,  57,  69,  56,
                                                        14,  17,  22,  29,  51,  87,  80,  62,
                                                        18,  22,  37,  56,  68, 109, 103,  77, 
                                                        24,  35,  55,  64,  81, 104, 113,  92,
                                                        49,  64,  78,  87, 103, 121, 120, 101,
                                                        72,  92,  95,  98, 112, 100, 103,  99},
                g_au8QTableStd1[64] = {17,  18,  24,  47,  99,  99,  99,  99,
                                                        18,  21,  26,  66,  99,  99,  99,  99,            
                                                        24,  26,  56,  99,  99,  99,  99,  99,            
                                                        47,  66,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99},
                g_au8QTableStd2[64] = {17,  18,  24,  47,  99,  99,  99,  99,
                                                        18,  21,  26,  66,  99,  99,  99,  99,            
                                                        24,  26,  56,  99,  99,  99,  99,  99,            
                                                        47,  66,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99};   


//#define 	UVC_SKIP_FRAME		4
UINT32 u32SkipFrame ;
UINT32 u32CurFrameIndex;

/* Current Format Index */
UINT32 u32CurFormatIndex;

/* Frame Buffer Index for VideoIN and JPEG Encode Buffer Change */
UINT32 frameBufferIndex;

/* Current Buffer Address for JPEG Encode */
UINT32 u32CurFrameAddress,g_u32CurBitstreamAddress_1;

/* Buffer Status */
BOOL volatile bIsFrameBuffer0,  bIsFrameBuffer1; /* 0 means buffer is clean */

BOOL volatile g_bWaitVIN;
UINT8 volatile u32PreviousBufIdx = 4;


extern UARTDEV_T* pUART0;

extern int g_iTarget;
extern UINT16	g_u16FixedWidth;
extern UINT16 	g_u16FixedHeight;	
extern UINT32 g_u32UartType;


void JpegEncoderCallback(UINT32 u32ImageSize)
{
  BufStatus[vid_out] = 0;
  vid_out++;
	if ( vid_out == ENCODE_BUFFERNO )
	    vid_out = 0;  
	           
  u32JPEGSize[jpeg_mid] = u32ImageSize;
 	EncodeStatus[jpeg_mid] = 1; 
	if ( u32ImageSize >= 0x20000 )
	{
		sysprintf("Image Size =%x\n",u32ImageSize);
	}
 	jpeg_mid++;
    if ( jpeg_mid == JPEG_BUFFERNO )
      jpeg_mid = 0;     	    
    
}

int audioSetBuffer(MV_CFG_T *ptMvCfg, UINT8 *pucPcmBuff, INT puFrameSize)
{

    INT32 i32SampleCount;
	
    if ( ptMvCfg == NULL )	
    {
    	g_pi16AudioBuf = (INT16 *)pucPcmBuff;
    	IN_DATA_BUF_NUM = puFrameSize >> 1;
    	return 0;
    }
    else if ( ptMvCfg == (MV_CFG_T *)1 ) // Get the unused data
    {
    	return ((s_i16RecInSample << 1));
    }
    else if ( ptMvCfg == (MV_CFG_T *)2 ) // Get the pointer of Buffer, and
    {
   	i32SampleCount = puFrameSize >> 1; // 2 bytes
   	    while ( GetPCMSampleData( (PINT16)pucPcmBuff,i32SampleCount) == 0 )
   	    {
   	    ;
   	    }
    	return ((INT32)pucPcmBuff);     	
    }
    return 0;
}
void  audioStartRecord(MV_CFG_T *ptMvCfg)
{
    if ( ptMvCfg == NULL )
    {	
	  	 g_runavi = 1;    
//sysprintf("start audio\n");	  	 
    	InitializeUAC(s_i32SampleRate);  // Sample rate = 16000KHz
    	StartUAC();	
//sysprintf("end audio\n");
    }
    else if ( ptMvCfg ==(MV_CFG_T *)1 )   // Set flags
    {
//sysprintf("audio begin to record\n");	  	
        last_time = sysGetTicks(TIMER0);  // begin record
    	bPlaying = TRUE;	
//sysprintf("audio begin processing\n");	 
    }
    
}

void  audioStopRecord(MV_CFG_T *ptMvCfg)
{
    StopUAC(); 
}

VOID  media_record_callback(MV_CFG_T *ptMvCfg)
{
	MV_INFO_T 		*ptMvInfo;


	
	mflGetMovieInfo(ptMvCfg, &ptMvInfo);

	if (sysGetTicks(TIMER0) - last_time > 100)
	{
		if ( bVideo_Only == TRUE )
		{
		sysprintf(" (Vid #%d - %d) \n",
			    ptMvInfo->uVidTotalFrames, ptMvInfo->uVidTotalFrames - last_vid_frame);		
		}
		else
		{
		sysprintf("T=%d.%02d  (Vid #%d - %d) (Audio #%d) \n",
				ptMvInfo->uMovieLength / 100, ptMvInfo->uMovieLength % 100,
			    ptMvInfo->uVidTotalFrames, ptMvInfo->uVidTotalFrames - last_vid_frame, s_i16RecInSample);
		}	

		last_time = sysGetTicks(TIMER0);
		last_vid_frame = ptMvInfo->uVidTotalFrames;
//		last_au_frame  = ptMvInfo->uAuTotalFrames;

       	i32CurTimer++;
#ifdef SMALL_BOARD		
// show LED  
        if ( i32CurTimer % 2 == 1 )
        {
        	outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20);	//GPIOA-5 output. 
			outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x20);	//GPIOA-5 output LOW. 	
        }
        else
        {
        	outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20);	//GPIOA-5 output. 
			outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) | 0x20);	//GPIOA-5 output LOW. 	        
        }
#endif		
       	if ( i32CurTimer >= TIME_NO )
       	{
			mflRecControl(ptMvCfg, REC_CTRL_STOP, 0);
       	} 


		if ( g_u32UartType == UART_HIGHSPEED)
   			skey = pUART0->UartGetChar_NoBlocking();			
		else       	
			skey = sysGetChar_NoBlocking();

//		if ( skey == 1 )
		if ( skey == '1' )
		{
			if ( g_u32UartType == UART_HIGHSPEED)			
       			pUART0->UartPutChar(0x39);   		
		   	sysprintf("Stop record\n");
		   	mflRecControl(ptMvCfg, REC_CTRL_STOP, 0);		   
    	}      
	}
	
	if ( skey == '2' ) //start snapshot
	{
		if ( g_u32UartType == UART_HIGHSPEED)		
   			pUART0->UartPutChar(0x39);   		
		mflRecControl(ptMvCfg, REC_CTRL_SNAPSHOT, 0);	
		skey = 0xFF;
		   
	}
	

}

INT mjpeg_init_encode(UINT8 *pucM4VHeader, UINT32 *puHeaderSize,BOOL bIsH263, UINT16 usImageWidth, UINT16 usImageHeight)
{
    *puHeaderSize = 0;
    return 0;
}


INT  mjpeg_encode_frame(PUINT8 *pucFrameBuff, UINT32 *puFrameSize)
{
//sysprintf("encoded %d\n", jpeg_out);	
		if ( ( bPlaying == FALSE ) || (	bVideo_Only == TRUE))
		{
			while (EncodeStatus[jpeg_out] == 0 );
		}
		else
		{
			if ( EncodeStatus[jpeg_out] == 0 )
			{
				*puFrameSize = 0;
				*pucFrameBuff = (PUINT8)((UINT32)(g_ZeroBuffer+8)|0x80000000);
//				sysprintf("0 video chunk\n");
				return 0;
			}
		}
//   sysprintf("jpeg encoded finished\n");    
		*puFrameSize = u32JPEGSize[jpeg_out];
				/* Set Address */

		*pucFrameBuff = (PUINT8)((UINT32)u32CurBitstreamAddress[jpeg_out]);					
//	 if ( *puFrameSize >= 0x10000 )
//	      sysprintf("Encoder size %x\n", *puFrameSize); 
	 EncodeStatus[jpeg_out] = 0;	 
	 jpeg_out++;
	 if ( jpeg_out == JPEG_BUFFERNO )
	    jpeg_out = 0;    
   return 0;
}

void mjpeg_rec_frame_done(PUINT8 *pucFrameBuff)
{
	 *pucFrameBuff = (PUINT8)((UINT32)g_pbySnapBuffer);	
 	 JpegStatus[jpeg_final] = 0; 
	 jpeg_final++;
	 if ( jpeg_final == JPEG_BUFFERNO )
	    jpeg_final = 0;           
}


void AVIEncOpen(void)
{

	INT i;
	char szFileName[40];
    INT nStatus;

    jpegPre();    

	memset(szFileName,0,40);
//	sprintf(szFileName, "C:\\vid\\smpl%04d.avi", sCurNo);	
	sprintf(szFileName, "C:\\smpl%04d.avi", sCurNo);		
	sysprintf("encoded file = %s\n", szFileName);
   	fsAsciiToUnicode(szFileName, g_suRecorderFile, TRUE);		
 	fsDeleteFile(g_suRecorderFile, NULL);



    g_runavi = 0;   
	tMvCfg.eOutMediaType   = MFL_MEDIA_AVI;
        if ( s_i32Type == PCM )
		tMvCfg.eAuCodecType    = MFL_CODEC_PCM;
	else
		tMvCfg.eAuCodecType    = MFL_CODEC_ADPCM;	
	
	tMvCfg.eVidCodecType   = MFL_CODEC_JPEG;

	tMvCfg.eOutStrmType    = MFL_STREAM_FILE;
	tMvCfg.suOutMediaFile  = g_suRecorderFile;
	tMvCfg.szOMFAscii      = NULL;
	tMvCfg.suOutMetaFile   = NULL;
	tMvCfg.szOTFAscii      = NULL;
	tMvCfg.bUseTempFile    = TRUE;

	if ( bVideo_Only == TRUE )
		tMvCfg.bIsRecordAudio  = FALSE;	
   	else
		tMvCfg.bIsRecordAudio  = TRUE;
	
	tMvCfg.nAudioRecVolume = 8; //_nAudioVolume;
		//tMvCfg.eAudioRecDevice = MFL_REC_I2S;
	tMvCfg.eAudioRecDevice = MFL_REC_ADC;
	tMvCfg.eAuRecSRate     = (AU_SRATE_E)s_i32SampleRate;  //AU_SRATE_16000;   // Sample Rate
	tMvCfg.nVidRecIntraIntval = 30;
        if ( s_i32Type == PCM )	
		tMvCfg.nAuRecChnNum    = 1;
        else
 		tMvCfg.nAuRecChnNum    = 2;       		
	tMvCfg.uAuBuffSizeDB   = 32 * 1024;
#ifdef SILENCE
	tMvCfg.uAuRecAvgBitRate = 0; //no audio
	tMvCfg.uAuRecMaxBitRate = 0; //no audio 
#else		
	tMvCfg.uAuRecAvgBitRate = 256000;
	tMvCfg.uAuRecMaxBitRate = 256000;
#endif
	tMvCfg.bIsRecordVideo  = TRUE;
	tMvCfg.nVidRecFrate    = s_i32FrameRate;     // Video Frame Rate
	tMvCfg.sVidRecWidth    = u16CurWidth;
	tMvCfg.sVidRecHeight   = u16CurHeight;
	tMvCfg.uVidBuffSizeDB  = 128 * 1024;
	tMvCfg.uVidRecAvgBitRate = 128000* s_i32FrameRate*2;
	tMvCfg.uVidRecMaxBitRate = 256000*s_i32FrameRate*2 ;
	if ( bVideo_Only == TRUE )	
		tMvCfg.param1		   = (MV_CFG_T *)((((UINT32)JPEG_BUFFERNO) << 27)|((UINT32)WITHOUT_AUDIO_TIME <<16)|TIME_NO); //(10 * idx);
	else	
		tMvCfg.param1		   = (MV_CFG_T *)((((UINT32)JPEG_BUFFERNO) << 27)|TIME_NO); //(10 * idx);

	tMvCfg.ap_time         = media_record_callback;
	tMvCfg.vid_init_encode = mjpeg_init_encode;
	tMvCfg.vid_enc_frame   = mjpeg_encode_frame;
	tMvCfg.vid_rec_frame_done = mjpeg_rec_frame_done;
	
	
	tMvCfg.au_on_start     = audioStartRecord;
	tMvCfg.au_on_stop      = audioStopRecord;
	tMvCfg.au_sbc_encode   = audioSetBuffer;
		
	i32CurTimer = 0;

    for (i=0; i< ENCODE_BUFFERNO; i++)
    {
        BufStatus[i] = 0;
    }
    for (i=0; i<JPEG_BUFFERNO; i++)
    {    
        EncodeStatus[i] = 0;   
        JpegStatus[i] = 0;
    }                
    
     vid_in = 0;
     vid_out = 0; 
     jpeg_out = 0;      
     jpeg_mid = 0;     
     jpeg_in=0;
     jpeg_final = 0;
	 u32VideoInIdx = 0;       


   	
	if ( bVideo_Only == TRUE )
		g_runavi = 1; 	
	 
	nStatus = mflMovieMaker(&tMvCfg);
	if (nStatus < 0)
	{ 
		sysprintf("Record error = %x\n", nStatus); 
		skey = 16; 		 
	}
   	 g_runavi = 0;
#ifdef SMALL_BOARD   	 
 	outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20);	//GPIOA-5 output. 
	outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x20);	//GPIOA-5 output LOW. 
#endif	
	sysprintf("AVI record done.\n");	
   	 
}


/* AVI Encoder Main */
void AVIEnc_main(void)
{
//    INT nStatus;
    
    last_vid_frame = 0;
	/* Open AVI encoder Device */
    AVIEncOpen();
}

/* UVC event */

/* Change VideoIN Buffer when Frame End */

void VideoIn_InterruptHandler(void)
{
	if ( g_iTarget == USB_UVC_UAC)
	{
	 // for only USB
		switch(u32VideoInIdx)
		{
			case 0:		
				if(bIsFrameBuffer1 == 0)
				{
					/* Change frame buffer 1 if Frame Buffer 1 is clean, Otherwise, do nothing */
					ChangeFrame(FALSE, (UINT32)u32PacketFrameBuffer1, u16CurWidth,u16CurHeight);					
					u32VideoInIdx = 1; 				
					g_bWaitVIN = FALSE;
				}
				else
				{
					g_bWaitVIN = TRUE;
				}	
				break; 	 				
			case 1:	
				if(bIsFrameBuffer0 == 0)	
				{
					/* Change frame buffer 2 if Frame Buffer 2 is clean, Otherwise, do nothing */		
					ChangeFrame(FALSE, (UINT32)u32PacketFrameBuffer0, u16CurWidth,u16CurHeight);								
 					u32VideoInIdx = 0;		
 					g_bWaitVIN = FALSE;
				} 
				else
				{
					g_bWaitVIN = TRUE;						
				}
				break; 	 				
 
		}
		if(u32SkipFrame != 0)
			u32SkipFrame--;	
		return;
	}
	else if ( g_iTarget == AVI_ENCODER )
	{
	switch(u32VideoInIdx)
	{
		case 0:		
		/* Change frame buffer 1 if Frame Buffer 1 is clean, Otherwise, do nothing */
		if ( g_runavi == 1 )
		{					
		if ( ( BufStatus[vid_in] == 0  ) && ( JpegStatus[jpeg_in] == 0 ))
		{
#if 0			
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,				
				0, 							//0 = Planar Y buffer address
				u32PacketFrameBuffer1 );							
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				1, 							//1 = Planar U buffer address
				u32PacketFrameBuffer1 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT);							
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				2, 							//2 = Planar V buffer address
				u32PacketFrameBuffer1 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT+OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT/4 );																					
#else
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PACKET,			
				0, 							//Packet buffer addrress 0	
				u32PacketFrameBuffer1 );			
#endif			
			u32VideoInIdx = 1; 				
			BufStatus[vid_in] = 1; 
      vid_in++;
      if ( vid_in == ENCODE_BUFFERNO )
       		vid_in = 0;
      u32CurBitstreamAddress[jpeg_in] = ((UINT32)u32BitstreamBuffer0+ MAX_JPEG_SIZE*jpeg_in);                       
      jpegEncode((UINT32)u32PacketFrameBuffer0,(UINT32)u32CurBitstreamAddress[jpeg_in], u16CurWidth,u16CurHeight);
			JpegStatus[jpeg_in] = 1;
			jpeg_in++;                       
                    	if ( jpeg_in == JPEG_BUFFERNO )
				jpeg_in = 0;  
//sysprintf("Video 0 = %d\n", jpeg_in);                         
       
		}
        	}					
		break; 	 				
		case 1:	
		if ( g_runavi == 1 )
		{					
    if ( ( BufStatus[vid_in] == 0  ) && ( JpegStatus[jpeg_in] == 0 ))
		{
 			/* Set Planar Buffer Address */						
#if 0			
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,				
				0, 							//0 = Planar Y buffer address
				u32PacketFrameBuffer0 );							
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				1, 							//1 = Planar U buffer address
				u32PacketFrameBuffer0 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT);							
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				2, 							//2 = Planar V buffer address
				u32PacketFrameBuffer0 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT+OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT/4 );
#else			
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PACKET,			
				0, 							//Packet buffer addrress 0	
				u32PacketFrameBuffer0 );					
#endif			
			u32VideoInIdx = 0;	
 
			BufStatus[vid_in] = 1;   
      vid_in++;
                    	if ( vid_in == ENCODE_BUFFERNO )
				vid_in = 0;
                       
			u32CurBitstreamAddress[jpeg_in] = ((UINT32)u32BitstreamBuffer0+ MAX_JPEG_SIZE*jpeg_in);                       
      jpegEncode((UINT32)u32PacketFrameBuffer1,(UINT32)u32CurBitstreamAddress[jpeg_in], u16CurWidth,u16CurHeight);
			JpegStatus[jpeg_in] = 1;                   	
			jpeg_in++;                       
      if ( jpeg_in == JPEG_BUFFERNO )
      	jpeg_in = 0;    
//sysprintf("Video 1 = %d\n", jpeg_in);                         
             	}
		}
		break; 	 	
	}  
	}	
}



void jpegAdjustUserQTAB(PUINT8 puQTableSrc, PUINT8 puQTableDest, int factor)
{
	volatile int i, temp;      
	if (factor <= 0) factor = 1;
	if (factor > 100) factor = 100;

	if (factor < 50)
		factor = 5000 / factor;
	else
		factor = 200 - factor * 2;

	for (i = 0; i < 64; i++)
	{
		temp = ((long) puQTableSrc[i] * (long) factor + (long)50) / (long)100;
        /* limit the values to the valid range */
		if (temp <= 0) temp = 1;
		if (temp > 255)
			temp = 255L; /* limit to baseline range if requested */
			puQTableDest[i] = (UINT8) temp;
	}
}


/* JPEG Encode function */
UINT32 jpegEncode(UINT32 u32YAddress,UINT32 u32BitstreamAddress, UINT16 u16Width,UINT16 u16Height)
//UINT32 jpegEncode(UINT32 u32BitstreamAddress)
{
	JPEG_INFO_T jpegInform;
		/* JPEG Init */
	if ( g_iTarget == USB_UVC_UAC )
	{
		jpegInit();	
						
		/* Set Source Y/U/V Stride */	       
		jpegIoctl(JPEG_IOCTL_SET_YSTRIDE, u16Width, 0);	   
		jpegIoctl(JPEG_IOCTL_SET_USTRIDE, u16Width/2, 0);
		jpegIoctl(JPEG_IOCTL_SET_VSTRIDE, u16Width/2, 0);			

	   	/* Set Source Address */	
		jpegIoctl(JPEG_IOCTL_SET_YADDR, u32YAddress, 0);
  	jpegIoctl(JPEG_IOCTL_SET_UADDR, (u32YAddress + u16Width * u16Height), 0);   		
		jpegIoctl(JPEG_IOCTL_SET_VADDR, (u32YAddress + u16Width*u16Height+u16Width*u16Height/2), 0);	
														
	    /* Set Bit stream Address */   
		jpegIoctl(JPEG_IOCTL_SET_BITSTREAM_ADDR, u32BitstreamAddress, 0);
	    	
		/* Encode mode, encoding primary image, YUV 4:2:0 */
		jpegIoctl(JPEG_IOCTL_SET_ENCODE_MODE, JPEG_ENC_SOURCE_PACKET, JPEG_ENC_PRIMARY_YUV422);		
	    
	    /* Primary Encode Image Width / Height */    
	    	jpegIoctl(JPEG_IOCTL_SET_DIMENSION, u16Height, u16Width);	
	    
		/* Include Quantization-Table and Huffman-Table */	
		jpegIoctl(JPEG_IOCTL_ENC_SET_HEADER_CONTROL, JPEG_ENC_PRIMARY_QTAB | JPEG_ENC_PRIMARY_HTAB, 0);
	       
		/* Use the default Quantization-table 0, Quantization-table 1 */
		jpegIoctl(JPEG_IOCTL_SET_DEFAULT_QTAB, 0, 0);
		
		/* Trigger JPEG encoder */
		jpegIoctl(JPEG_IOCTL_ENCODE_TRIGGER, 0, 0);  
	    
	    /* Wait for complete */
		if(jpegWait())
		{
			jpegGetInfo(&jpegInform);
			return jpegInform.image_size[0];		
	    }
	    else
	    	return 0;		
	}  	
// AVI_Encoder				
	jpegInit();	
			
		/* Set Source Y/U/V Stride */	       
	jpegIoctl(JPEG_IOCTL_SET_YSTRIDE, u16Width, 0);	   
	jpegIoctl(JPEG_IOCTL_SET_USTRIDE, u16Width/2, 0);
	jpegIoctl(JPEG_IOCTL_SET_VSTRIDE, u16Width/2, 0);			

	   	/* Set Source Address */	
	jpegIoctl(JPEG_IOCTL_SET_YADDR, u32YAddress, 0);
 	jpegIoctl(JPEG_IOCTL_SET_UADDR, (u32YAddress + u16Width * u16Height), 0);   		
//	jpegIoctl(JPEG_IOCTL_SET_VADDR, (u32YAddress + u16Width*u16Height+u16Width*u16Height/4), 0);	
	jpegIoctl(JPEG_IOCTL_SET_VADDR, (u32YAddress + u16Width*u16Height+u16Width*u16Height/2), 0);		
								
	    /* Set Bit stream Address */   
	jpegIoctl(JPEG_IOCTL_SET_BITSTREAM_ADDR, u32BitstreamAddress, 0);
	    	
		/* Encode mode, encoding primary image, YUV 4:2:0 */
	jpegIoctl(JPEG_IOCTL_SET_ENCODE_MODE, JPEG_ENC_SOURCE_PACKET, JPEG_ENC_PRIMARY_YUV422);		
//  jpegIoctl(JPEG_IOCTL_SET_ENCODE_MODE, JPEG_ENC_SOURCE_PLANAR, JPEG_ENC_PRIMARY_YUV420);	
        	    		    
	    /* Primary Encode Image Width / Height */    
	jpegIoctl(JPEG_IOCTL_SET_DIMENSION, u16Height, u16Width);	       
	
   	        //Set Encode Source Image Height        
	jpegIoctl(JPEG_IOCTL_SET_SOURCE_IMAGE_HEIGHT, u16Height, 0);
 
		/* 	Include Quantization-Table and Huffman-Table */	
	jpegIoctl(JPEG_IOCTL_ENC_SET_HEADER_CONTROL, JPEG_ENC_PRIMARY_QTAB | JPEG_ENC_PRIMARY_HTAB, 0);
  
	       
		/* Use the default Quantization-table 0, Quantization-table 1 */

	//jpegIoctl(JPEG_IOCTL_SET_DEFAULT_QTAB, 0, 0);
#if 0		
        jpegAdjustUserQTAB(g_au8QTableStd0, g_au8QTableUser0, 75);
        jpegAdjustUserQTAB(g_au8QTableStd1, g_au8QTableUser1, 75);
#endif
		jpegSetQTAB(g_au8QTableUser0,g_au8QTableUser1, 0, 2);
	
	/* Trigger JPEG encoder */
		jpegIoctl(JPEG_IOCTL_ENCODE_TRIGGER, 0, 0);  

	    /* Wait for complete */
   	return 0;
    	
}

/* JPEG Encode function */
void jpegPre(void)
{

        jpegAdjustUserQTAB(g_au8QTableStd0, g_au8QTableUser0, 60);
        jpegAdjustUserQTAB(g_au8QTableStd1, g_au8QTableUser1, 60);
		
}

// USB UVC 

/* UVC Main */
void uavc_main(void)
{
	/* Skip frames */
	u32SkipFrame = 0;   //UVC_SKIP_FRAME;	
    u32CurFrameIndex = 1;
    u32CurFormatIndex = 1;

/* Frame Buffer Index for VideoIN and JPEG Encode Buffer Change */
    frameBufferIndex = 0;
    bIsFrameBuffer0=0;
   	bIsFrameBuffer1=0; /* 0 means buffer is clean */

    g_bWaitVIN = 0;
    u32VideoInIdx = 0;
	
	while(u32SkipFrame)
		GetImageBuffer();
	
	/* Open USB Device */
	udcOpen();
	/* Init USB Device Setting as Video Class Device */
	uavcdInit(ProcessUnitControl,NULL, Send_AudioOneMSPacket);		
	/* Init USB Device */
	udcInit();
	/* Deal with UVC event */	
	uvcdEvent();
	/* Deinit USB Device */
	udcDeinit();	
	/* Cloase USB Device */
	udcClose();
	sysprintf("UVC end\n");
}


/* UVC event */
void uvcdEvent(void)
{
	UINT8 volatile u8OpenMic,result;
    UINT32 volatile u32Addr,u32transferSize;   
    UINT32 volatile i;
	
	InitializeUAC(16000);  // Sample rate = 16000KHz
	u8OpenMic = 0;
	i = 0;
	while (1)	
	{
		 if ( usbdStatus.usbConnected == 1 )
			 break;
		 i++;
		 if ( i > 4000000)
			 break;
	}
	while (1)
	{		
		if(usbdStatus.appConnected == 1)
		{  
	    		while(g_bWaitVIN)
			{
				bIsFrameBuffer1 = 0; 	
			  	bIsFrameBuffer0 = 0; 	
		    	}	    	
	    		
	    	/* Get Image Data */
			result = GetImage(&u32Addr, &u32transferSize);
			
			if(result)	/* If frame isn't updated, Do nothing */
			{
	 			/* Send Image */	
		  		uavcdSendImage(u32Addr, u32transferSize, uvcStatus.StillImage);
			 	/* Wait for Complete */ 	
		  		while(!uavcdIsReady());	  	
		  		 	 				
			  	bIsFrameBuffer1 = 0; 	
			  	bIsFrameBuffer0 = 0;
		  	}			
		}
		if(usbdStatus.appConnected_Audio == 1)   // audio start
		{
			if ( u8OpenMic == 0 )
			{
				u8OpenMic = 1;
				StartUAC();
			}
		}
		else if ( usbdStatus.appConnected_Audio == 0 )
		{
            		if (u8OpenMic == 1)
			{
				u8OpenMic = 0;
				StopUAC();
			}
		}
		if(usbdStatus.usbConnected == 0)		
		{
		 // disconnect
			break;
		}
	
	}
}

/* Get Image Size and Address (Image data control for Foramt and Frame)*/
INT GetImageBuffer(void)
{
	switch(u32VideoInIdx)
	{
		case 1:	/* Check Frame Buffer 1 is dirty */
				u32CurFrameAddress = (UINT32)u32PacketFrameBuffer0;	
				g_u32CurBitstreamAddress_1 = (UINT32)(u32BitstreamBuffer0+MAX_JPEG_SIZE*4);
				bIsFrameBuffer0 = 1; 
				break;		
		case 0: 
				/* Check Frame Buffer 2 is dirty */
				u32CurFrameAddress = (UINT32)u32PacketFrameBuffer1;	
				g_u32CurBitstreamAddress_1 = (UINT32)(u32BitstreamBuffer0+MAX_JPEG_SIZE*8);
				bIsFrameBuffer1 = 1; 
				break;
	}	
	if(u32VideoInIdx == u32PreviousBufIdx)	/* Skip the frame that had already been encoded */
		return 0;							
	else
		u32PreviousBufIdx = u32VideoInIdx;	/* Update u32PreviousBufIdx */
	return 1;	
}

/* Change VideoIN Setting for Frame size */
void ChangeFrame(BOOL bChangeSize, UINT32 u32Address, UINT16 u16Width,UINT16 u16Height)
{
	UINT32 u32GCD;
	
	if(bChangeSize)	/* Change Frame Size */
	{
		u32GCD = GCD(u16Height, OPT_CROP_HEIGHT);						 							 
		videoinIoctl(VIDEOIN_IOCTL_VSCALE_FACTOR,
					eVIDEOIN_PACKET,			
					u16Height/u32GCD,
					OPT_CROP_HEIGHT/u32GCD);	
		u32GCD = GCD(u16Width, OPT_CROP_WIDTH);																
		videoinIoctl(VIDEOIN_IOCTL_HSCALE_FACTOR,
					eVIDEOIN_PACKET,			
					u16Width/u32GCD,
					OPT_CROP_WIDTH/u32GCD);		
	}
	/* Set Buffer Address */
	videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PACKET,			
				0, 							//Packet buffer addrress
				(UINT32)u32Address);	
	videoinIoctl(VIDEOIN_IOCTL_SET_STRIDE,										
				u16Width,				
				u16Width,
				0);								
}

/* Get Image Size and Address (Image data control for Foramt and Frame) */
INT GetImage(PUINT32 pu32Addr, PUINT32 pu32transferSize)
{
	INT result;

	/* Get Image Buffer (Return 0 if frame isn't updated) */
	result = GetImageBuffer();
	
	if(!result)		/* If frame isn't updated */
		return 0;	/* Skip the frame that had already been encoded */
	
	if(uvcStatus.StillImage)	/* Snapshot */
	{   
		/* UVC_Foramt_YUY2 */	
        if(uvcStatus.snapshotFormatIndex == UVC_Format_YUY2)
        {    
    		*pu32transferSize = uvcStatus.snapshotMaxVideoFrameSize;   
			if(u32CurFrameIndex != uvcStatus.snapshotFrameIndex || u32CurFormatIndex != uvcStatus.snapshotFormatIndex)
			{				
				/* Frame Size Changed */
            	switch(uvcStatus.snapshotFrameIndex)
            	{										
					case UVC_STILL_VGA:							
						u16CurWidth = g_u16FixedWidth;
						u16CurHeight = g_u16FixedHeight;	
						break;										
					case UVC_STILL_QVGA:							
						u16CurWidth = g_u16FixedWidth/2;
						u16CurHeight = g_u16FixedHeight/2;
						break;			
					case UVC_STILL_QQVGA:									
						u16CurWidth = g_u16FixedWidth/4;
						u16CurHeight = g_u16FixedHeight/4;
						break;													
            	} 
            	/* Set VideoIn Setting for Frame Size */
            	ChangeFrame(TRUE, u32CurFrameAddress, u16CurWidth,u16CurHeight);
				u32CurFrameIndex = uvcStatus.snapshotFrameIndex;	
				u32CurFormatIndex = uvcStatus.snapshotFormatIndex; 		
				
				/* Skip frames */
				u32SkipFrame = UVC_SKIP_FRAME;					

				while(u32SkipFrame)
			   		GetImageBuffer();							
			}
			*pu32Addr = u32CurFrameAddress;
        }        
       	else	/* UVC_Foramt_MJPEG */		
		{
			if(u32CurFrameIndex != uvcStatus.snapshotFrameIndex ||u32CurFormatIndex != uvcStatus.snapshotFormatIndex)
			{
				/* Frame Size Changed */
            	switch(uvcStatus.snapshotFrameIndex)
            	{										
					case UVC_STILL_VGA:							
						u16CurWidth = g_u16FixedWidth;
						u16CurHeight = g_u16FixedHeight;	
						break;										
					case UVC_STILL_QVGA:							
						u16CurWidth = g_u16FixedWidth/2;
						u16CurHeight = g_u16FixedHeight/2;
						break;			
					case UVC_STILL_QQVGA:									
						u16CurWidth = g_u16FixedWidth/4;
						u16CurHeight = g_u16FixedHeight/4;
						break;													
            	} 
            	/* Set VideoIn Setting for Frame Size */
            	ChangeFrame(TRUE, u32CurFrameAddress, u16CurWidth,u16CurHeight);
				u32CurFrameIndex = uvcStatus.snapshotFrameIndex;	
				u32CurFormatIndex = uvcStatus.snapshotFormatIndex;				
				/* Skip frames */
				u32SkipFrame = UVC_SKIP_FRAME;					
				while(u32SkipFrame)
			   		GetImageBuffer();					
			}	
			/* Encode JPEG */
			*pu32transferSize = (jpegEncode((UINT32)u32CurFrameAddress,(UINT32)g_u32CurBitstreamAddress_1, u16CurWidth,u16CurHeight) + 3) & ~0x03;
			/* Set Address */
			*pu32Addr = (UINT32)g_u32CurBitstreamAddress_1;	
		}
		
	}
	else					/* Preview */
	{         						
        switch (uvcStatus.FormatIndex)
        {        
			case UVC_Format_YUY2:		/* UVC_Foramt_YUY2 */
        	{     	
	   			*pu32transferSize = uvcStatus.MaxVideoFrameSize;	   			
				if(u32CurFrameIndex != uvcStatus.FrameIndex || u32CurFormatIndex != uvcStatus.FormatIndex)
				{
					/* Frame Size Changed */
//					sysDelay(100);
	            	switch(uvcStatus.FrameIndex)
	            	{										
						case UVC_VGA:							
							u16CurWidth = g_u16FixedWidth;
							u16CurHeight = g_u16FixedHeight;	
							break;										
						case UVC_QVGA:							
							u16CurWidth = g_u16FixedWidth/2;
							u16CurHeight = g_u16FixedHeight/2;
							break;			
						case UVC_QQVGA:									
							u16CurWidth = g_u16FixedWidth/4;
							u16CurHeight = g_u16FixedHeight/4;
							break;													
	            	} 
	            	/* Set VideoIn Setting for Frame Size */
	            	ChangeFrame(TRUE, u32CurFrameAddress, u16CurWidth,u16CurHeight);					
					u32CurFrameIndex = uvcStatus.FrameIndex;	
					u32CurFormatIndex = uvcStatus.FormatIndex; 		
					/* Skip frames */
					u32SkipFrame = UVC_SKIP_FRAME;	
					
					while(u32SkipFrame)
						GetImageBuffer();
				}	
				*pu32Addr = u32CurFrameAddress;
				break;			
            }            
        	case UVC_Foramt_MJPEG:     /* UVC_Foramt_MJPEG */
        	{		
				if(u32CurFrameIndex != uvcStatus.FrameIndex || u32CurFormatIndex != uvcStatus.FormatIndex)
				{
					/* Frame Size Changed */
//								sysDelay(100);
	            	switch(uvcStatus.FrameIndex)
	            	{										
						case UVC_VGA:							
							u16CurWidth = g_u16FixedWidth;
							u16CurHeight = g_u16FixedHeight;	
							break;										
						case UVC_QVGA:							
							u16CurWidth = g_u16FixedWidth/2;
							u16CurHeight = g_u16FixedHeight/2;
							break;			
						case UVC_QQVGA:									
							u16CurWidth = g_u16FixedWidth/4;
							u16CurHeight = g_u16FixedHeight/4;
							break;													
	            	} 
	            	/* Set VideoIn Setting for Frame Size */
	            	ChangeFrame(TRUE, u32CurFrameAddress, u16CurWidth,u16CurHeight);
					u32CurFrameIndex = uvcStatus.FrameIndex;	
					u32CurFormatIndex = uvcStatus.FormatIndex; 	
					/* Skip frames */
					u32SkipFrame = UVC_SKIP_FRAME;	
				}	
				/* Encode JPEG */
				*pu32transferSize = (jpegEncode((UINT32)u32CurFrameAddress,(UINT32)g_u32CurBitstreamAddress_1, u16CurWidth,u16CurHeight) + 3) & ~0x03;
				/* Set Address */
				*pu32Addr = (UINT32)g_u32CurBitstreamAddress_1;				             
				break;			
            }
   		}       	
   					      				   
	}
	return 1;
}

/* Process Unit Control */
UINT32 ProcessUnitControl(UINT32 u32ItemSelect,UINT32 u32Value)
{
	switch(u32ItemSelect)
	{
		case PU_BACKLIGHT_COMPENSATION_CONTROL:
				//sysprintf("Set Backlight -> %d\n",u32Value);
				break;			
		case PU_BRIGHTNESS_CONTROL:
				//sysprintf("Set Brightness -> %d\n",u32Value);
				break;			
		case PU_CONTRAST_CONTROL:
				//sysprintf("Set Contrast -> %d\n",u32Value);	
			 	break;			
		case PU_HUE_CONTROL:
				//sysprintf("Set Hue -> %d\n",u32Value);	
			 	break;			
		case PU_SATURATION_CONTROL:
				//sysprintf("Set Saturation -> %d\n",u32Value);	
			 	break;			
		case PU_SHARPNESS_CONTROL:
				//sysprintf("Set Sharpness -> %d\n",u32Value);	
			 	break;			
		case PU_GAMMA_CONTROL:		
				//sysprintf("Set Gamma -> %d\n",u32Value);			
			 	break;
		case PU_POWER_LINE_FREQUENCY_CONTROL:	
				//sysprintf("Set Power Line Frequency -> %d\n",u32Value);		
			 	break;		
/* audio function */			 	
		case PU_MUTE_CONTROL:	
				//sysprintf("Audio Mute function -> %d\n",u32Value);		
			 	break;		
		case PU_VOLUME_CONTROL:	
//				sysprintf("Audio Volume function -> %d\n",u32Value);		
			 	break;			 	
			 		 	
			 		 	
	}
	return 0;
}

