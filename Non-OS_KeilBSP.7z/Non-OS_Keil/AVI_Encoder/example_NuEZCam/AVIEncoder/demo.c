/***************************************************************************
 *                                                                         *
 * Copyright (c) 2008 Nuvoton Technolog. All rights reserved.              *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include "wblib.h"

#include "W55FA93_GPIO.h"
#include "W55FA93_VideoIn.h"
#include "demo.h"
#include "jpegcodec.h"
#include "w55fa93_sic.h"
#include "w55fa93_gnand.h"
#include "nvtfat.h"
#include "usbd.h"
#include "mass_storage_class.h"
#include "videoclass.h"

#define DETECT_USBD_PLUG

		
#define VGA_RES		1
#define HD_RES		2	

#define VGA_NT99050		1
#define VGA_GC0308		2
#define HD_NT99141		3


extern void JpegEncoderCallback(UINT32 u32ImageSize);			
IQ_S  SensorIQ;
IQ_S* pSensorIQ;
BOOL volatile gbMT99050 = FALSE;

extern UINT32 skey;
int sCurNo;

// HUART
UINT32 g_u32Idx=0;
volatile BOOL bIsTimeOut=0;
char pi8UartBuf[10010];

UINT32 g_u32Len; 
UINT32 g_u32Valid = 0;
UINT32 g_u32Timeout = 0;

UINT32 u32LenR[30]={0};
UINT32 u32LenPtr = 0;

UARTDEV_T UART0;	/*High speed */
UARTDEV_T* pUART0;

int  OPT_STRIDE;		  
int  OPT_CROP_WIDTH;		 
int  OPT_CROP_HEIGHT;		   
int  OPT_PREVIEW_WIDTH;		 
int  OPT_PREVIEW_HEIGHT;	  

int  OPT_ENCODE_WIDTH;   	
int  OPT_ENCODE_HEIGHT;  
UINT16 u16CurWidth, u16CurHeight;
int WITHOUT_AUDIO_TIME;
BOOL bVideo_Only;
INT32	s_i32FrameRate;  //30

	
int iSensorResolution;
volatile int g_iTarget;
UINT16	g_u16FixedWidth;
UINT16 	g_u16FixedHeight;	
volatile UINT32 g_u32UartType;

BOOL PlugDetection(void)
{
#ifdef DETECT_USBD_PLUG
	return udcIsAttached();	
#else
	return TRUE;
#endif	
}

void UartDataValid_Handler(UINT8* buf, UINT32 u32Len)
{
	UINT32 u32Idx = 0;
	g_u32Len = u32Len;
	g_u32Valid = g_u32Valid+1;

	memcpy(&(pi8UartBuf[g_u32Idx]), buf, u32Len);
	g_u32Idx = g_u32Idx+u32Len;	

	
	while(u32Idx++<u32Len)
	{
		if(*buf++ =='q')
		{
			bIsTimeOut = 1;
			break;
		}		
	}		
}

void UartDataTimeOut_Handler(UINT8* buf, UINT32 u32Len)
{
	UINT32 u32Idx = 0;
	g_u32Timeout = g_u32Timeout+1;

	memcpy(&(pi8UartBuf[g_u32Idx]), buf, u32Len);
	g_u32Idx = g_u32Idx+u32Len;	
	
	while(u32Idx++<u32Len)
	{
		if(*buf++ =='q')
		{
			bIsTimeOut = 1;
			break;
		}	
	}		
}

void CloseIP()
{
	
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | USBH_CKE);				//USB Host disable
	outp32(0xb1009200, 0x08000000);
	sysprintf("Disable USB Transceiver\n");

	outp32(REG_APBCLK, inp32(REG_APBCLK) | ADC_CKE);					//ADC disable 
	outp32 (REG_ADC_CON, inp32(REG_ADC_CON) & ~ADC_CON_ADC_EN);
	outp32(REG_MISCR, inp32(REG_MISCR) & ~LVR_EN);		
	sysprintf("Disable ADC and LVR\n");
	outp32(REG_APBCLK, inp32(REG_APBCLK) & ~ADC_CKE);
	
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | (SPU_CKE | ADO_CKE));		//DAC VDD33 power down 															
	outp32(REG_SPU_DAC_VOL, inp32(REG_SPU_DAC_VOL) | ANA_PD);		//DAC SPU HPVDD33														//DAC SPU VDD33															
	sysprintf("Disable SPU and ADO\n");
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) & ~(SPU_CKE | ADO_CKE));															

													
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | USBD_CKE);				//USB phy disable
	outp32(PHY_CTL, 0x0);
	sysprintf("Disable USB phy\n");
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) & ~USBD_CKE);
	
	outp32(REG_GPIOA_OMD, 0x0);
	outp32(REG_GPIOA_PUEN, 0x3FF);

	outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x80);	//GPIOA-7 output. 
	outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x80);	//GPIOA-7 output LOW. 	
	
/*
	outp32(REG_GPDFUN, (inp32(REG_GPDFUN)| 0x22));	
	outp32(REG_APBCLK, inp32(REG_APBCLK) & ~PWM_CKE);
*/	
	
}
	
int main()
{
	UINT32 u32Upll_Clock;
	INT32 g_i32SD0TotalSector;		
	/*Due to I2C share pins with UART, the SerialIO can not be used*/
	int ch2;
	int status;
	
	WB_UART_T uart;
	UINT32 u32Item, u32ExtFreq;

	memset(pi8UartBuf, 0, 1024);
	u32ExtFreq = sysGetExternalClock();
//Initialize HUART
#ifdef SMALL_BOARD
	register_uart_device(0, &UART0);
  pUART0 = &UART0;
  pUART0->UartPort(0);
	uart.uiFreq = u32ExtFreq*1000;
	uart.uiBaudrate = 115200;
	uart.uiDataBits = WB_DATA_BITS_8;
	uart.uiStopBits = WB_STOP_BITS_1;
	uart.uiParity = WB_PARITY_NONE;
	uart.uiRxTriggerLevel = LEVEL_1_BYTE;
  pUART0->UartInitialize(&uart);
  pUART0->UartEnableInt(UART_INT_NONE);		
  pUART0->UartInstallcallback(0, UartDataValid_Handler);	
  pUART0->UartInstallcallback(1, UartDataTimeOut_Handler);		
#endif
	sysUartPort(1);		

	
	CloseIP();	

	sysSetSystemClock(eSYS_UPLL, 	//E_SYS_SRC_CLK eSrcClk,	
					192000,			//UINT32 u32PllKHz, 	
					192000,			//UINT32 u32SysKHz,
					192000/2,		//UINT32 u32CpuKHz,
					192000/2,		//UINT32 u32HclkKHz,
					  192000/4);	//UINT32 u32ApbKHz									  
					  
	sysEnableCache(CACHE_WRITE_BACK);
	
	/* start timer 0 */
	sysSetTimerReferenceClock(TIMER0, sysGetExternalClock()*1000);
	sysStartTimer(TIMER0, 100, PERIODIC_MODE); 
	
	/* Initial file system */
	fsInitFileSystem();
	
  sysDelay(200); 	
#ifdef _N32903_
	sysprintf("The code is for N32903\n");
#else
	sysprintf("the code is for N32901\n");
#endif	

	
	DBG_PRINTF("================================================================\n");
	DBG_PRINTF("Please select the target								\n");    	
	DBG_PRINTF("================================================================\n");	    	
	ch2 = 0x39;
	sCurNo = 1;	
loop1:	
	g_iTarget = 0;
	
	do
	{    
		DBG_PRINTF("================================================================\n");
		DBG_PRINTF(" [1] AVI Encoder										\n");	
		DBG_PRINTF(" [2] USB UVC+UAC 									\n");		
		DBG_PRINTF(" [3] USB MSC    									\n");					
		DBG_PRINTF("================================================================\n");

		while (1)
		{
			g_u32UartType = 0;
#ifdef SMALL_BOARD			
			u32Item = pUART0->UartGetChar_NoBlocking();
			if ( (u32Item == '1') || (u32Item == '2') || (u32Item == '3'))
			{
				sysprintf("Select %c\n",u32Item);					
				g_u32UartType = UART_HIGHSPEED;
				break;
			}
			
#else  // close normal UART		
			u32Item = sysGetChar_NoBlocking();
			if ( (u32Item == '1') || (u32Item == '2') || (u32Item == '3'))
			{
				sysprintf("Select %c\n",u32Item);						
				g_u32UartType = UART_NORMAL;
				break;
			}
#endif			
		}
		
		if ( u32Item == '1' )
		{
			g_iTarget  = AVI_ENCODER;
			if ( g_u32UartType == UART_HIGHSPEED)
				pUART0->UartPutChar(ch2);
			break;
		}   
		
 		if ( u32Item == '2' )
		{
			g_iTarget = USB_UVC_UAC;
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
			break;
		}   
		
 		if ( u32Item == '3' )
		{
			g_iTarget = USB_MSC;
			if ( g_u32UartType == UART_HIGHSPEED)
				pUART0->UartPutChar(ch2);
			break;
		}   
	}while (1);
	
	if ( g_iTarget == USB_MSC )
	{
		udcOpen();		 
		sicIoctl(SIC_SET_CLOCK, 192000, 0, 0);		
		sicOpen();
		status = sicSdOpen0();
		if(status < 0)
		{
			sicSdClose0();		
			sysprintf("SD card fails\n");			
			goto loop1;
		}
	//		sysprintf("Press 4 to exit USB MSC !\n");
		mscdInit();
		mscdFlashInit(NULL,status);				
		udcInit();
		mscdMassEvent(PlugDetection);	
		mscdDeinit();	
		udcDeinit();	
		udcClose();
		
		sicClose();		
		goto loop1;
	}
//	i= 0;
//	ch1 = '1';
	ch2 = 0x39;
	
again:	
    status = 0;  // ok
	do
	{    
		DBG_PRINTF("================================================================\n");
		DBG_PRINTF(" [1] NT99050 demo - 640X480										\n");	
		DBG_PRINTF(" [2] GC0308 demo - 640X480										\n");			
		DBG_PRINTF(" [3] NT99141 demo - 1280X720									\n");				
		DBG_PRINTF(" [4] Exit																			\n");			
		DBG_PRINTF("================================================================\n");

		if ( g_u32UartType == UART_HIGHSPEED)	
   			u32Item = pUART0->UartGetChar();		
		else
			u32Item = sysGetChar();	
sysprintf("Select %c\n",u32Item);				
		if ( u32Item == '1' )
		{
			iSensorResolution = VGA_NT99050;
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
		   break;
		}   
		
	  	if ( u32Item == '2' )
		{
			iSensorResolution = VGA_GC0308;
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
		   break;
		}   

	  	if ( u32Item == '3' )
		{
			iSensorResolution = HD_NT99141;
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
		   break;
		}   
		if ( u32Item == '4' )
		{
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
			goto loop1;
		}   
	}while (1);

	u32PacketFrameBuffer0 = ((UINT32) u8FrameBuffer0 | 0x80000000); // + BITSTREAM_OFFSET; 
	u32PacketFrameBuffer1 = ((UINT32) u8FrameBuffer1 | 0x80000000); // + BITSTREAM_OFFSET; 
	u32BitstreamBuffer0 = ((UINT32)u8BitstreamBuffer0| 0x80000000)+8;
		
// UVC + UAC		
	if (g_iTarget == USB_UVC_UAC)
	{
		if (iSensorResolution == VGA_NT99050)		
		{
			uavcdSetResolution(0);  // set VGA
			OPT_STRIDE=640;  
			OPT_CROP_WIDTH=	640; 
			OPT_CROP_HEIGHT=480;   
			OPT_PREVIEW_WIDTH=640; 
			OPT_PREVIEW_HEIGHT=480;  
			OPT_ENCODE_WIDTH =640;
			OPT_ENCODE_HEIGHT=480;	
			g_u16FixedWidth = u16CurWidth =640;
			g_u16FixedHeight = u16CurHeight=480;
			register_sensor(&SensorIQ);			
			gbMT99050 = TRUE;			
			if ( Smpl_NT99050((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail )
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				goto again;						
			}
			else
			{
				sysprintf("Sensor NT99050 is OK\n");
			}							
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MIN = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MAX = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_DEF = 0;
			uvcPuInfo.PU_BRIGHTNESS_MIN = 0;
			uvcPuInfo.PU_BRIGHTNESS_MAX = 255;
			uvcPuInfo.PU_BRIGHTNESS_DEF = SensorIQ.IQ_GetBrightness();
			uvcPuInfo.PU_CONTRAST_MIN = 0;
			uvcPuInfo.PU_CONTRAST_MAX = 255;
			uvcPuInfo.PU_CONTRAST_DEF = SensorIQ.IQ_GetContrast();
			uvcPuInfo.PU_HUE_MIN = 0;
			uvcPuInfo.PU_HUE_MAX = 255;
			uvcPuInfo.PU_HUE_DEF = SensorIQ.IQ_GetHue();
			uvcPuInfo.PU_SATURATION_MIN = 0;
			uvcPuInfo.PU_SATURATION_MAX = 0;
			uvcPuInfo.PU_SATURATION_DEF = 0;
			uvcPuInfo.PU_SHARPNESS_MIN = 0;
			uvcPuInfo.PU_SHARPNESS_MAX =255;
			uvcPuInfo.PU_SHARPNESS_DEF = SensorIQ.IQ_GetSharpness();
			uvcPuInfo.PU_GAMMA_MIN = 0;
			uvcPuInfo.PU_GAMMA_MAX = 0;
			uvcPuInfo.PU_GAMMA_DEF = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MIN = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MAX = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_DEF = 0; 	
		}
		else if (iSensorResolution == VGA_GC0308)
		{
			uavcdSetResolution(0);  // set VGA
			OPT_STRIDE=640;  
			OPT_CROP_WIDTH=	640; 
			OPT_CROP_HEIGHT=480;   
			OPT_PREVIEW_WIDTH=640; 
			OPT_PREVIEW_HEIGHT=480;  
			OPT_ENCODE_WIDTH =640;
			OPT_ENCODE_HEIGHT=480;	
			g_u16FixedWidth = u16CurWidth =640;
			g_u16FixedHeight = u16CurHeight=480;
			if (Smpl_GC0308((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				goto again;
			}			
			else
			{
				sysprintf("Sensor GC0308 is OK\n");
			}			
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MIN = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MAX = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_DEF = 0;
			uvcPuInfo.PU_BRIGHTNESS_MIN = 0;
			uvcPuInfo.PU_BRIGHTNESS_MAX = 255;
			uvcPuInfo.PU_BRIGHTNESS_DEF = 128; //SensorIQ.IQ_GetBrightness();
			uvcPuInfo.PU_CONTRAST_MIN = 0;
			uvcPuInfo.PU_CONTRAST_MAX = 255;
			uvcPuInfo.PU_CONTRAST_DEF = 128; //SensorIQ.IQ_GetContrast();
			uvcPuInfo.PU_HUE_MIN = 0;
			uvcPuInfo.PU_HUE_MAX = 255;
			uvcPuInfo.PU_HUE_DEF = 128; //SensorIQ.IQ_GetHue();
			uvcPuInfo.PU_SATURATION_MIN = 0;
			uvcPuInfo.PU_SATURATION_MAX = 0;
			uvcPuInfo.PU_SATURATION_DEF = 0;
			uvcPuInfo.PU_SHARPNESS_MIN = 0;
			uvcPuInfo.PU_SHARPNESS_MAX =255;
			uvcPuInfo.PU_SHARPNESS_DEF = 128; //SensorIQ.IQ_GetSharpness();
			uvcPuInfo.PU_GAMMA_MIN = 0;
			uvcPuInfo.PU_GAMMA_MAX = 0;
			uvcPuInfo.PU_GAMMA_DEF = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MIN = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MAX = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_DEF = 0; 
		}
		else if (iSensorResolution == HD_NT99141)
		{
			uavcdSetResolution(1);  // set HD				
			OPT_STRIDE=1280;  
			OPT_CROP_WIDTH=	1280; 
			OPT_CROP_HEIGHT=720;   
			OPT_PREVIEW_WIDTH=1280; 
			OPT_PREVIEW_HEIGHT=720;  
			OPT_ENCODE_WIDTH =1280;
			OPT_ENCODE_HEIGHT=720;	
			g_u16FixedWidth = u16CurWidth =1280;
			g_u16FixedHeight = u16CurHeight=720;	
			if ( Smpl_NT99141_HD((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)				
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				goto again;	
			}			
			else
			{
				sysprintf("Sensor NT99141 is OK\n");			
			}
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MIN = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MAX = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_DEF = 0;
			uvcPuInfo.PU_BRIGHTNESS_MIN = 0;
			uvcPuInfo.PU_BRIGHTNESS_MAX = 255;
			uvcPuInfo.PU_BRIGHTNESS_DEF = 128; //SensorIQ.IQ_GetBrightness();
			uvcPuInfo.PU_CONTRAST_MIN = 0;
			uvcPuInfo.PU_CONTRAST_MAX = 255;
			uvcPuInfo.PU_CONTRAST_DEF = 128; //SensorIQ.IQ_GetContrast();
			uvcPuInfo.PU_HUE_MIN = 0;
			uvcPuInfo.PU_HUE_MAX = 255;
			uvcPuInfo.PU_HUE_DEF = 128; //SensorIQ.IQ_GetHue();
			uvcPuInfo.PU_SATURATION_MIN = 0;
			uvcPuInfo.PU_SATURATION_MAX = 0;
			uvcPuInfo.PU_SATURATION_DEF = 0;
			uvcPuInfo.PU_SHARPNESS_MIN = 0;
			uvcPuInfo.PU_SHARPNESS_MAX =255;
			uvcPuInfo.PU_SHARPNESS_DEF = 128; //SensorIQ.IQ_GetSharpness();
			uvcPuInfo.PU_GAMMA_MIN = 0;
			uvcPuInfo.PU_GAMMA_MAX = 0;
			uvcPuInfo.PU_GAMMA_DEF = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MIN = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MAX = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_DEF = 0; 	
		}
		jpegOpen ();    
		uavc_main();					
		jpegClose(); 	
		videoIn_Close();			
		goto loop1;			
	}

	while(1) {
		while (1) {
			DBG_PRINTF("\nCamera status \n");
			DBG_PRINTF(" [1] Normal photography \n");
			DBG_PRINTF(" [2] Time lapse photography \n");	
			DBG_PRINTF(" [3] Exit    \n");						
			if ( g_u32UartType == UART_HIGHSPEED)
				skey = pUART0->UartGetChar();	
			else
				skey = sysGetChar();
sysprintf("Select %c\n",skey);					
			if ( skey == '1')
			{
				bVideo_Only = FALSE;
				DBG_PRINTF(" Select [1] \n");			
				break;
			}
			else if ( skey == '2')
			{
				bVideo_Only = TRUE;
				WITHOUT_AUDIO_TIME= 1; // 1 seconds
				DBG_PRINTF(" Select [2] \n");			
				break;
			}
			else if ( skey == '3')
			{
				goto loop1;
			}						
		}
#ifdef SMALL_BOARD		
		outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20);	//GPIOA-5 output. 
		outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x20);	//GPIOA-5 output LOW. 
#endif	
	{
		status = 0;
		skey = 0xFF;
		sysprintf("Start Record\n");
		sysprintf("Press 1 to stop, 2 to capture one image !\n");
	/*-----------------------------------------------------------------------*/
	/*  Init SD card                                                       			*/
	/*-----------------------------------------------------------------------*/
		u32Upll_Clock = sysGetPLLOutputKhz(eSYS_UPLL, sysGetExternalClock());
		sicIoctl(SIC_SET_CLOCK, u32Upll_Clock, 0, 0);
		sicOpen();
		g_i32SD0TotalSector = sicSdOpen0();	/* Total sector or error code */
		if(g_i32SD0TotalSector < 0)
		{
			sysprintf("no SD card or SD card fail\n");
			sysprintf("\nPlease insert SD card\n");
//      sicSdClose0();
			goto sd_fail;            	
		}
		fsAssignDriveNumber('C', DISK_TYPE_SD_MMC, 0, 1);
		if ( iSensorResolution == VGA_NT99050 )
		{
			OPT_STRIDE=640;  
			OPT_CROP_WIDTH=	640; 
			OPT_CROP_HEIGHT=480;   
			OPT_PREVIEW_WIDTH=320; 
			OPT_PREVIEW_HEIGHT=240;  
			OPT_ENCODE_WIDTH =640;
			OPT_ENCODE_HEIGHT=480;	
			u16CurWidth =640;
			u16CurHeight=480;
			s_i32FrameRate = 30;			
			register_sensor(&SensorIQ);			
			if ( Smpl_NT99050((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail )
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				status = 1;
				goto sd_fail;
			}
			else
			{
				sysprintf("Sensor NT99050 is OK\n");
			}
		}   
		else if ( iSensorResolution == VGA_GC0308)
		{
			OPT_STRIDE=640;  
			OPT_CROP_WIDTH=	640; 
			OPT_CROP_HEIGHT=480;   
			OPT_PREVIEW_WIDTH=320; 
			OPT_PREVIEW_HEIGHT=240;  
			OPT_ENCODE_WIDTH =640;
			OPT_ENCODE_HEIGHT=480;	
			u16CurWidth =640;
			u16CurHeight=480;
			s_i32FrameRate = 30;			
			if (Smpl_GC0308((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				status = 1;
				goto sd_fail;
			}
			else
			{
				sysprintf("Sensor GC0308 is OK\n");
			}								
		}
		else if ( iSensorResolution == HD_NT99141 )
		{
			OPT_STRIDE=1280;  
			OPT_CROP_WIDTH=	1280; 
			OPT_CROP_HEIGHT=720;   
			OPT_PREVIEW_WIDTH=320; 
			OPT_PREVIEW_HEIGHT=240;  
			OPT_ENCODE_WIDTH =1280;
			OPT_ENCODE_HEIGHT=720;	
			u16CurWidth =1280;
			u16CurHeight=720;
			s_i32FrameRate = 20;						
			if ( Smpl_NT99141_HD((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				status = 1;
				goto sd_fail;	
			}			
			else
			{
				sysprintf("Sensor NT99141 is OK\n");
			}
		}
		jpegOpenEx (NULL, JpegEncoderCallback); 
// Pass, it could work
		if ( g_u32UartType == UART_HIGHSPEED)	
			pUART0->UartPutChar(ch2);
		AVIEnc_main();		
		jpegClose(); 	
		sCurNo++;		
sd_fail:	
		videoIn_Close();
		sicSdClose0();
		sicClose();			
	}       
	if ( status == 1 )
    	goto again;
	}	// while

	sysStopTimer(TIMER0);
	sysDisableCache();
    
	return 0;
} /* end main */
