/***************************************************************************
 *                                                                         *
 * Copyright (c) 2008 Nuvoton Technolog. All rights reserved.              *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include "wblib.h"

#include "W55FA93_GPIO.h"
#include "W55FA93_VideoIn.h"
#include "demo.h"
#include "jpegcodec.h"
#include "w55fa93_sic.h"
#include "w55fa93_gnand.h"
#include "nvtfat.h"

		
#define VGA_RES		1
#define HD_RES		2	

extern void JpegEncoderCallback(UINT32 u32ImageSize);			
IQ_S SensorIQ=0;
IQ_S* pSensorIQ;
extern UINT32 skey;
int sCurNo;

// HUART
UINT32 g_u32Idx=0;
volatile BOOL bIsTimeOut=0;
char pi8UartBuf[10010];

UINT32 g_u32Len; 
UINT32 g_u32Valid = 0;
UINT32 g_u32Timeout = 0;

UINT32 u32LenR[30]={0};
UINT32 u32LenPtr = 0;

UARTDEV_T UART0;	/*High speed */
UARTDEV_T* pUART0;

int  OPT_STRIDE;		  
int  OPT_CROP_WIDTH;		 
int  OPT_CROP_HEIGHT;		   
int  OPT_PREVIEW_WIDTH;		 
int  OPT_PREVIEW_HEIGHT;	  

int  OPT_ENCODE_WIDTH;   	
int  OPT_ENCODE_HEIGHT;  
UINT16 u16CurWidth, u16CurHeight;
int WITHOUT_AUDIO_TIME;
BOOL bVideo_Only;
INT32	s_i32FrameRate;  //30

	
int iSensorResolution;
void UartDataValid_Handler(UINT8* buf, UINT32 u32Len)
{
	UINT32 u32Idx = 0;
	g_u32Len = u32Len;
	g_u32Valid = g_u32Valid+1;

	memcpy(&(pi8UartBuf[g_u32Idx]), buf, u32Len);
	g_u32Idx = g_u32Idx+u32Len;	

	
	while(u32Idx++<u32Len)
	{
		if(*buf++ =='q')
		{
			bIsTimeOut = 1;
			break;
		}		
	}		
}

void UartDataTimeOut_Handler(UINT8* buf, UINT32 u32Len)
{
	UINT32 u32Idx = 0;
	g_u32Timeout = g_u32Timeout+1;

	memcpy(&(pi8UartBuf[g_u32Idx]), buf, u32Len);
	g_u32Idx = g_u32Idx+u32Len;	
	
	while(u32Idx++<u32Len)
	{
		if(*buf++ =='q')
		{
			bIsTimeOut = 1;
			break;
		}	
	}		
}

void CloseIP()
{
	
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | USBH_CKE);				//USB Host disable
	outp32(0xb1009200, 0x08000000);
	sysprintf("Disable USB Transceiver\n");

	outp32(REG_APBCLK, inp32(REG_APBCLK) | ADC_CKE);					//ADC disable 
	outp32 (REG_ADC_CON, inp32(REG_ADC_CON) & ~ADC_CON_ADC_EN);
	outp32(REG_MISCR, inp32(REG_MISCR) & ~LVR_EN);		
	sysprintf("Disable ADC and LVR\n");
	outp32(REG_APBCLK, inp32(REG_APBCLK) & ~ADC_CKE);
	
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | (SPU_CKE | ADO_CKE));		//DAC VDD33 power down 															
	outp32(REG_SPU_DAC_VOL, inp32(REG_SPU_DAC_VOL) | ANA_PD);		//DAC SPU HPVDD33														//DAC SPU VDD33															
	sysprintf("Disable SPU and ADO\n");
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) & ~(SPU_CKE | ADO_CKE));															

													
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | USBD_CKE);				//USB phy disable
	outp32(PHY_CTL, 0x0);
	sysprintf("Disable USB phy\n");
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) & ~USBD_CKE);
	
	outp32(REG_GPIOA_OMD, 0x0);
	outp32(REG_GPIOA_PUEN, 0x3FF);

	outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x80);	//GPIOA-7 output. 
	outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x80);	//GPIOA-7 output LOW. 	
	
/*
	outp32(REG_GPDFUN, (inp32(REG_GPDFUN)| 0x22));	
	outp32(REG_APBCLK, inp32(REG_APBCLK) & ~PWM_CKE);
*/	
	
}
	
int main()
{
	UINT32 u32Upll_Clock;
	INT32 g_i32SD0TotalSector;		
	/*Due to I2C share pins with UART, the SerialIO can not be used*/
	int i, ch1, ch2;
	int status;
	
    WB_UART_T uart;
	char* pi8String;
	UINT8 u8Item;
	UINT32 u32Len;
	UINT32 u32Item, u32ExtFreq;
	UINT32 u32Count;
	INT8 i8UartData=0; 
	memset(pi8UartBuf, 0, 1024);
	u32ExtFreq = sysGetExternalClock();
//Initialize HUART
#ifdef ARDUINO
	register_uart_device(0, &UART0);
   	pUART0 = &UART0;
   	pUART0->UartPort(0);
	uart.uiFreq = u32ExtFreq*1000;
	uart.uiBaudrate = 115200;
	uart.uiDataBits = WB_DATA_BITS_8;
	uart.uiStopBits = WB_STOP_BITS_1;
	uart.uiParity = WB_PARITY_NONE;
	uart.uiRxTriggerLevel = LEVEL_1_BYTE;
   	pUART0->UartInitialize(&uart);
   	pUART0->UartEnableInt(UART_INT_NONE);		
   	pUART0->UartInstallcallback(0, UartDataValid_Handler);	
   	pUART0->UartInstallcallback(1, UartDataTimeOut_Handler);		
#endif
	sysUartPort(1);		
//#endif	
	
        CloseIP();	

	sysSetSystemClock(eSYS_UPLL, 	//E_SYS_SRC_CLK eSrcClk,	
					192000,			//UINT32 u32PllKHz, 	
					192000,			//UINT32 u32SysKHz,
					192000/2,		//UINT32 u32CpuKHz,
					192000/2,		//UINT32 u32HclkKHz,
					  192000/4);	//UINT32 u32ApbKHz									  
					  
	sysEnableCache(CACHE_WRITE_BACK);
	
	/* start timer 0 */
	sysSetTimerReferenceClock(TIMER0, sysGetExternalClock()*1000);
	sysStartTimer(TIMER0, 100, PERIODIC_MODE); 
	
	/* Initial file system */
	fsInitFileSystem();
	
	
#ifdef _N32903_
sysprintf("The code is for N32903\n");
#else
sysprintf("the code is for N32901\n");
#endif	

	
	DBG_PRINTF("================================================================\n");
	DBG_PRINTF("Please use LCD HANNSTAR_HSD043I9W1								\n");    	
	DBG_PRINTF("================================================================\n");	    	
	
	i= 0;
	ch1 = '1';
	ch2 = 0x39;
again:	
    status = 0;  // ok
	do
	{    
	

		
		DBG_PRINTF("================================================================\n");
		DBG_PRINTF("				VideoIn library demo code						\n");
//		DBG_PRINTF(" [1] OV7670 demo 												\n");
//		DBG_PRINTF(" [2] OV7725 demo 												\n");		
		DBG_PRINTF(" [1] NT99050 demo - 640X480										\n");	
		DBG_PRINTF(" [2] NT99141 demo - 1280X720									\n");				
		DBG_PRINTF("================================================================\n");

		//u32Item = '2';
//		i++;
#ifdef ARDUINO		
       	u32Item = pUART0->UartGetChar();		
sysprintf("%d received the character = %c\n",  i, u32Item);
#else
		u32Item = sysGetChar();	
#endif		
//		if ( u32Item == '1' || u32Item == '2' || u32Item == '3' )
		if ( u32Item == '1' )
		{
			iSensorResolution = VGA_RES;
#ifdef ARDUINO		
        pUART0->UartPutChar(ch2);
#endif
		   break;
		}   
		
  		if ( u32Item == '2' )
		{
			iSensorResolution = HD_RES;
#ifdef ARDUINO		
        pUART0->UartPutChar(ch2);
#endif
		   break;
		}   


    }while (1);
	
	sysprintf("Start !\n");

	u32PacketFrameBuffer0 = ((UINT32) u8FrameBuffer0 | 0x80000000); // + BITSTREAM_OFFSET; 
	u32PacketFrameBuffer1 = ((UINT32) u8FrameBuffer1 | 0x80000000); // + BITSTREAM_OFFSET; 
	u32BitstreamBuffer0 = ((UINT32)u8BitstreamBuffer0| 0x80000000)+8;

	sCurNo = 0;
	while(1) {
	
		while (1) {
			if ( iSensorResolution == VGA_RES )
			{
				DBG_PRINTF("Resolution \n");
				DBG_PRINTF(" [1] QVGA (320 x240) \n");
				DBG_PRINTF(" [2] VGA (640 x480) \n");		
			}
			else if (iSensorResolution == HD_RES )
			{
				DBG_PRINTF("Resolution \n");
				DBG_PRINTF(" [1] QHD (640 x 360) \n");
				DBG_PRINTF(" [2] HD (1280 x 720) \n");		
			}
		

#ifdef ARDUINO		
       	skey = pUART0->UartGetChar();	
#else
		skey = sysGetChar();
#endif     
			if ( iSensorResolution == VGA_RES )
			{   
		        if ( skey == '1')
				{
					OPT_STRIDE=320;  
					OPT_CROP_WIDTH=	640; 
					OPT_CROP_HEIGHT=480;   
					OPT_PREVIEW_WIDTH=320; 
					OPT_PREVIEW_HEIGHT=240;  
					OPT_ENCODE_WIDTH =320;
					OPT_ENCODE_HEIGHT=240;	
					u16CurWidth =320;
					u16CurHeight=240;
					s_i32FrameRate = 30;			
#ifdef ARDUINO		
			        pUART0->UartPutChar(ch2);
#endif			
					DBG_PRINTF(" Select [1], QVGA \n");
					break;
				}
				else if ( skey == '2' )
				{
					OPT_STRIDE=640;  
					OPT_CROP_WIDTH=	640; 
					OPT_CROP_HEIGHT=480;   
					OPT_PREVIEW_WIDTH=320; 
					OPT_PREVIEW_HEIGHT=240;  
					OPT_ENCODE_WIDTH =640;
					OPT_ENCODE_HEIGHT=480;	
					u16CurWidth =640;
					u16CurHeight=480;
					s_i32FrameRate = 30;			
#ifdef ARDUINO		
			        pUART0->UartPutChar(ch2);
#endif			
					DBG_PRINTF(" Select [2], VGA \n");				 		
					break;
				}
			}
			else if ( iSensorResolution == HD_RES )
			{   
		        if ( skey == '1')
				{
					OPT_STRIDE=320;  
					OPT_CROP_WIDTH=	1280; 
					OPT_CROP_HEIGHT=720;   
					OPT_PREVIEW_WIDTH=320; 
					OPT_PREVIEW_HEIGHT=240;  
					OPT_ENCODE_WIDTH =640;
					OPT_ENCODE_HEIGHT=360;	
					u16CurWidth =640;
					u16CurHeight=360;
					s_i32FrameRate = 20;			
#ifdef ARDUINO		
			        pUART0->UartPutChar(ch2);
#endif			
					DBG_PRINTF(" Select [1], QHD \n");
					break;
				}
				else if ( skey == '2' )
				{
					OPT_STRIDE=1280;  
					OPT_CROP_WIDTH=	1280; 
					OPT_CROP_HEIGHT=720;   
					OPT_PREVIEW_WIDTH=320; 
					OPT_PREVIEW_HEIGHT=240;  
					OPT_ENCODE_WIDTH =1280;
					OPT_ENCODE_HEIGHT=720;	
					u16CurWidth =1280;
					u16CurHeight=720;
					s_i32FrameRate = 20;			
#ifdef ARDUINO		
			        pUART0->UartPutChar(ch2);
#endif			
					DBG_PRINTF(" Select [2], HD \n");				 		
					break;
				}
			}			
		}
		while (1) {
		DBG_PRINTF("\nCamera status \n");
		DBG_PRINTF(" [1] Normal photography \n");
		DBG_PRINTF(" [2] Time lapse photography \n");		
		
#ifdef ARDUINO		
       	skey = pUART0->UartGetChar();	
#else
		skey = sysGetChar();
#endif        

        if ( skey == '1')
		{
			bVideo_Only = FALSE;
			
//#ifdef ARDUINO		
//        pUART0->UartPutChar(ch2);
//#endif			
			DBG_PRINTF(" Select [1] \n");			
			break;
		}
		else if ( skey == '2')
		{
			bVideo_Only = TRUE;
			WITHOUT_AUDIO_TIME= 1; // 1 seconds
//#ifdef ARDUINO		
//        pUART0->UartPutChar(ch2);
//#endif			
			DBG_PRINTF(" Select [2] \n");			
			break;
		}
		}

	{
		skey = 0xFF;
		sCurNo++;
	    sysprintf("Start Record\n");
//	    sysprintf("Press 1 to stop, 2 to capture one image !\n");
	    sysprintf("Press 1 to stop !\n");		
	/*-----------------------------------------------------------------------*/
	/*  Init SD card                                                       			*/
	/*-----------------------------------------------------------------------*/
		u32Upll_Clock = sysGetPLLOutputKhz(eSYS_UPLL, sysGetExternalClock());
		sicIoctl(SIC_SET_CLOCK, u32Upll_Clock, 0, 0);
		sicOpen();
    	g_i32SD0TotalSector = sicSdOpen0();	/* Total sector or error code */
    	if(g_i32SD0TotalSector < 0)
    	{
    		sysprintf("no SD card or SD card fail\n");
    		sysprintf("\nPlease insert SD card\n");
           	sicSdClose0();
           	goto sd_fail;            	
		}
		fsAssignDriveNumber('C', DISK_TYPE_SD_MMC, 0, 1);
			    
#ifdef __UVC_VIN__
	if ( iSensorResolution == VGA_RES )
	{
		register_sensor(&SensorIQ);			
		if ( Smpl_NT99050((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail )
		{
			sysprintf("Sensor fail !\n");
			sysprintf("Please check the sensor !\n");
			status = 1;
			goto sd_fail;	
		}			

	}   
	else if ( iSensorResolution == HD_RES )
	{
     	if ( Smpl_NT99141_HD((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)
		{
			sysprintf("Sensor fail !\n");
			sysprintf("Please check the sensor !\n");
			status = 1;
			goto sd_fail;	
		}			
     	
	}
   	jpegOpenEx (NULL, JpegEncoderCallback); 
#endif		
// Pass, it could work
#ifdef ARDUINO		
        pUART0->UartPutChar(ch2);
#endif	
	

	    AVIEnc_main();		
	    jpegClose(); 	
sd_fail:	
    
        videoIn_Close();
   	    sicSdClose0();
   	    sicClose();			                
	}   // if
    
    if ( status == 1 )
    	goto again;
    }	// while

	
//   	sicSdClose0();
//   	sicClose();
   	sysStopTimer(TIMER0);
    sysDisableCache();
    
    return 0;
} /* end main */