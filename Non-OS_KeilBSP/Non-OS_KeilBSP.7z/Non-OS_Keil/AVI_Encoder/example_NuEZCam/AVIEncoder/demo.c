/***************************************************************************
 *                                                                         *
 * Copyright (c) 2008 Nuvoton Technolog. All rights reserved.              *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include "wblib.h"

#include "W55FA93_GPIO.h"
#include "W55FA93_VideoIn.h"
#include "demo.h"
#include "jpegcodec.h"
#include "w55fa93_sic.h"
#include "w55fa93_gnand.h"
#include "nvtfat.h"
#include "usbd.h"
#include "mass_storage_class.h"
#include "videoclass.h"

#define DETECT_USBD_PLUG

		
#define VGA_RES		1
#define HD_RES		2	

#define VGA_NT99050		1
#define VGA_GC0308		2
#define HD_NT99141		3

#define LED_ON() { \
		outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20); \
		outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x20); \
}

#define LED_OFF() { \
		outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20);	\
		outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) | 0x20);	\
}

extern void JpegEncoderCallback(UINT32 u32ImageSize);			
IQ_S  SensorIQ;
IQ_S* pSensorIQ;
BOOL volatile gbMT99050 = FALSE;

extern UINT32 skey;
int sCurNo;

// HUART
UINT32 g_u32Idx=0;
volatile BOOL bIsTimeOut=0;
char pi8UartBuf[10010];

UINT32 g_u32Len; 
UINT32 g_u32Valid = 0;
UINT32 g_u32Timeout = 0;

UINT32 u32LenR[30]={0};
UINT32 u32LenPtr = 0;

UARTDEV_T UART0;	/*High speed */
UARTDEV_T* pUART0;

int  OPT_STRIDE;		  
int  OPT_CROP_WIDTH;		 
int  OPT_CROP_HEIGHT;		   
int  OPT_PREVIEW_WIDTH;		 
int  OPT_PREVIEW_HEIGHT;	  

int  OPT_ENCODE_WIDTH;   	
int  OPT_ENCODE_HEIGHT;  
UINT16 u16CurWidth, u16CurHeight;
int WITHOUT_AUDIO_TIME;
BOOL bVideo_Only;
INT32	s_i32FrameRate;  //30

	
int iSensorResolution;
volatile int g_iTarget;
UINT16	g_u16FixedWidth;
UINT16 	g_u16FixedHeight;	
volatile UINT32 g_u32UartType;

UINT32 volatile skpi_key;
static unsigned char _int;
UINT32 volatile curTimer;
UINT32 volatile g_status;
UINT8 volatile g_CommandStatus;
UINT8 HighUartGetChar(void);
void HighUartPutChar(UINT8 u8CMDSTA, UINT8 u8Status);

BOOL PlugDetection(void)
{
#ifdef DETECT_USBD_PLUG
	return udcIsAttached();	
#else
	return TRUE;
#endif	
}

void UartDataValid_Handler(UINT8* buf, UINT32 u32Len)
{
	UINT32 u32Idx = 0;
	g_u32Len = u32Len;
	g_u32Valid = g_u32Valid+1;

	memcpy(&(pi8UartBuf[g_u32Idx]), buf, u32Len);
	g_u32Idx = g_u32Idx+u32Len;	

	
	while(u32Idx++<u32Len)
	{
		if(*buf++ =='q')
		{
			bIsTimeOut = 1;
			break;
		}		
	}		
}

void UartDataTimeOut_Handler(UINT8* buf, UINT32 u32Len)
{
	UINT32 u32Idx = 0;
	g_u32Timeout = g_u32Timeout+1;

	memcpy(&(pi8UartBuf[g_u32Idx]), buf, u32Len);
	g_u32Idx = g_u32Idx+u32Len;	
	
	while(u32Idx++<u32Len)
	{
		if(*buf++ =='q')
		{
			bIsTimeOut = 1;
			break;
		}	
	}		
}

void CloseIP()
{
	
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | USBH_CKE);				//USB Host disable
	outp32(0xb1009200, 0x08000000);
	sysprintf("Disable USB Transceiver\n");

	outp32(REG_APBCLK, inp32(REG_APBCLK) | ADC_CKE);					//ADC disable 
	outp32 (REG_ADC_CON, inp32(REG_ADC_CON) & ~ADC_CON_ADC_EN);
	outp32(REG_MISCR, inp32(REG_MISCR) & ~LVR_EN);		
	sysprintf("Disable ADC and LVR\n");
	outp32(REG_APBCLK, inp32(REG_APBCLK) & ~ADC_CKE);
	
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | (SPU_CKE | ADO_CKE));		//DAC VDD33 power down 															
	outp32(REG_SPU_DAC_VOL, inp32(REG_SPU_DAC_VOL) | ANA_PD);		//DAC SPU HPVDD33														//DAC SPU VDD33															
	sysprintf("Disable SPU and ADO\n");
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) & ~(SPU_CKE | ADO_CKE));															

													
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | USBD_CKE);				//USB phy disable
	outp32(PHY_CTL, 0x0);
	sysprintf("Disable USB phy\n");
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) & ~USBD_CKE);
	
	outp32(REG_GPIOA_OMD, 0x0);
	outp32(REG_GPIOA_PUEN, 0x3FF);

	outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x80);	//GPIOA-7 output. 
	outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x80);	//GPIOA-7 output LOW. 	
	
/*
	outp32(REG_GPDFUN, (inp32(REG_GPDFUN)| 0x22));	
	outp32(REG_APBCLK, inp32(REG_APBCLK) & ~PWM_CKE);
*/	
	
}

// warning LED
void WarningLED(void)
{
	int i;
	for (i=0; i<10; i++)
	{
		LED_ON();
		sysDelay(20); // delay 200 ms
		LED_OFF();
		sysDelay(20);
	}
}
// UART protocol begin
UINT8 HighUartGetChar(void)
{
	UINT8 u8Val, u8RetVal;
#if 1
// 0x5A6B7C8D + command + status
	if ( g_u32UartType == UART_HIGHSPEED)
	   	u8Val = pUART0->UartGetChar_NoBlocking();			
	else       	
		u8Val = sysGetChar_NoBlocking();
	// check  0x5A6B7C8D to be existed
//if ( u8Val != 0xFF)	
//   sysprintf("Input1 = %x\n", u8Val);	
	if ( u8Val == 0x8D )
	{
		sysDelay(1);		// delay 10 ms
		if ( g_u32UartType == UART_HIGHSPEED)
		   	u8Val = pUART0->UartGetChar_NoBlocking();
		else       	
			u8Val = sysGetChar_NoBlocking();
//sysprintf("Input2 = %x\n", u8Val);			
		if ( u8Val == 0x7C )
		{
			sysDelay(1);		// delay 10 ms
			if ( g_u32UartType == UART_HIGHSPEED)
		   		u8Val = pUART0->UartGetChar_NoBlocking();
			else       	
				u8Val = sysGetChar_NoBlocking();
//sysprintf("Input3 = %x\n", u8Val);				
			if (u8Val == 0x6B)
			{
				sysDelay(1);		// delay 10 ms
				if ( g_u32UartType == UART_HIGHSPEED)
		   			u8Val = pUART0->UartGetChar_NoBlocking();
				else       	
					u8Val = sysGetChar_NoBlocking();
//sysprintf("Input4 = %x\n", u8Val);					
				if ( u8Val == 0x5A )
				{
					sysDelay(1);		// delay 10 ms
					if ( g_u32UartType == UART_HIGHSPEED)
		   				u8Val = pUART0->UartGetChar_NoBlocking();
					else       	
						u8Val = sysGetChar_NoBlocking();
//sysprintf("Input5 = %x\n", u8Val);						
// command begin
					if ( u8Val == CMD_AVIEncoder)
					{
						sysDelay(1);		// delay 10 ms
						if ( g_u32UartType == UART_HIGHSPEED)
		   					u8Val = pUART0->UartGetChar_NoBlocking();
						else       	
							u8Val = sysGetChar_NoBlocking();
//sysprintf("Input6 = %x\n", u8Val);							
						if ( u8Val == AVI_START ) // START
						{
							if ( ( skpi_key == AVI_NORMAL) && (g_iTarget == UNKNOWN_DEVICE))
							{
								skpi_key = AVI_START;
								g_CommandStatus = CMD_AVIEncoder | AVI_START;
								return '1';
							}
							else
							{
								u8RetVal = CMD_AVIEncoder | AVI_START;
								return u8RetVal;	
							}
						}
						else if ( ( u8Val == AVI_CAPTURE ) && (g_iTarget == AVI_ENCODER))// capture one image
						{
							if ( skpi_key == AVI_START)
							{
								skpi_key = AVI_CAPTURE;
								g_CommandStatus = CMD_AVIEncoder | AVI_CAPTURE;
								return '2';
							}
							else
							{
								u8RetVal = CMD_AVIEncoder | AVI_CAPTURE;
								return u8RetVal;	
							}
						}
						else if ( ( u8Val == AVI_STOP ) && (g_iTarget == AVI_ENCODER))// capture one image
						{
							if ( skpi_key == AVI_START)
							{
								skpi_key = AVI_NORMAL;
								g_CommandStatus = CMD_AVIEncoder | AVI_STOP;
								return '1';
							}
							else
							{
								u8RetVal = CMD_AVIEncoder | AVI_STOP;
								return u8RetVal;	
							}
						}
						else
						{
							u8RetVal = CMD_AVIEncoder | u8Val;
							return u8RetVal;
						}
					}
					else if ( u8Val == CMD_UVCUAC )
					{
						if ( g_u32UartType == UART_HIGHSPEED)
		   					u8Val = pUART0->UartGetChar_NoBlocking();
						else       	
							u8Val = sysGetChar_NoBlocking();
						if ( ( u8Val == AVI_START ) && (g_iTarget == UNKNOWN_DEVICE))// START
						{
							if ( skpi_key == AVI_NORMAL)
							{
								skpi_key = AVI_START;
								g_CommandStatus = CMD_UVCUAC | AVI_START;
								return '2';
							}
							else
							{
								u8RetVal = CMD_UVCUAC | AVI_START;
								return u8RetVal;	
							}
						}
					}
					else if ( u8Val == CMD_USBMSC )
					{
						if ( g_u32UartType == UART_HIGHSPEED)
		   					u8Val = pUART0->UartGetChar_NoBlocking();
						else       	
							u8Val = sysGetChar_NoBlocking();
						if ( u8Val == AVI_START ) // START
						{
							if ( (skpi_key == AVI_NORMAL) && (g_iTarget == UNKNOWN_DEVICE))
							{
								skpi_key = AVI_START;
								g_CommandStatus = CMD_USBMSC | AVI_START;
								return '3';
							}
							else
							{
								u8RetVal = CMD_USBMSC | AVI_START;
								return u8RetVal;	
							}
						}
					}
// command end
				}
			}
		}
	}
#else

	// 0x295A384F+ command + status
	if ( g_u32UartType == UART_HIGHSPEED)
	   	u8Val = pUART0->UartGetChar_NoBlocking();			
	else       	
		u8Val = sysGetChar_NoBlocking();
	// check  0x5A6B7C8D to be existed
if ( u8Val != 0xFF)	
   sysprintf("Input = %d, str = %c\n", u8Val, u8Val);	
	if ( u8Val == 0x4F )
	{
		if ( g_u32UartType == UART_HIGHSPEED)
		   	u8Val = pUART0->UartGetChar_NoBlocking();
		else       	
			u8Val = sysGetChar_NoBlocking();
		if ( u8Val == 0x38 )
		{
			if ( g_u32UartType == UART_HIGHSPEED)
		   		u8Val = pUART0->UartGetChar_NoBlocking();
			else       	
				u8Val = sysGetChar_NoBlocking();
			if (u8Val == 0x5A)
			{
				if ( g_u32UartType == UART_HIGHSPEED)
		   			u8Val = pUART0->UartGetChar_NoBlocking();
				else       	
					u8Val = sysGetChar_NoBlocking();
				if ( u8Val == 0x29 )
				{
					if ( g_u32UartType == UART_HIGHSPEED)
		   				u8Val = pUART0->UartGetChar_NoBlocking();
					else       	
						u8Val = sysGetChar_NoBlocking();
// command begin
					if ( u8Val == CMD_AVIEncoder)
					{
						if ( g_u32UartType == UART_HIGHSPEED)
		   					u8Val = pUART0->UartGetChar_NoBlocking();
						else       	
							u8Val = sysGetChar_NoBlocking();
						if ( u8Val == AVI_START ) // START
						{
							if ( ( skpi_key == AVI_NORMAL) && (g_iTarget == UNKNOWN_DEVICE))
							{
								skpi_key = AVI_START;
								g_CommandStatus = CMD_AVIEncoder | AVI_START;
								return '1';
							}
							else
							{
								u8RetVal = CMD_AVIEncoder | AVI_START;
								return u8RetVal;	
							}
						}
						else if ( ( u8Val == AVI_CAPTURE ) && (g_iTarget == AVI_ENCODER))// capture one image
						{
							if ( skpi_key == AVI_START)
							{
								skpi_key = AVI_CAPTURE;
								g_CommandStatus = CMD_AVIEncoder | AVI_CAPTURE;
								return '2';
							}
							else
							{
								u8RetVal = CMD_AVIEncoder | AVI_CAPTURE;
								return u8RetVal;	
							}
						}
						else if ( ( u8Val == AVI_STOP ) && (g_iTarget == AVI_ENCODER))// capture one image
						{
							if ( skpi_key == AVI_START)
							{
								skpi_key = AVI_NORMAL;
								g_CommandStatus = CMD_AVIEncoder | AVI_STOP;
								return '1';
							}
							else
							{
								u8RetVal = CMD_AVIEncoder | AVI_STOP;
								return u8RetVal;	
							}
						}
						else
						{
							u8RetVal = CMD_AVIEncoder | u8Val;
							return u8RetVal;
						}
					}
					else if ( u8Val == CMD_UVCUAC )
					{
						if ( g_u32UartType == UART_HIGHSPEED)
		   					u8Val = pUART0->UartGetChar_NoBlocking();
						else       	
							u8Val = sysGetChar_NoBlocking();
						if ( ( u8Val == AVI_START ) && (g_iTarget == UNKNOWN_DEVICE))// START
						{
							if ( skpi_key == AVI_NORMAL)
							{
								skpi_key = AVI_START;
								g_CommandStatus = CMD_UVCUAC | AVI_START;
								return '2';
							}
							else
							{
								u8RetVal = CMD_UVCUAC | AVI_START;
								return u8RetVal;	
							}
						}
					}
					else if ( u8Val == CMD_USBMSC )
					{
						if ( g_u32UartType == UART_HIGHSPEED)
		   					u8Val = pUART0->UartGetChar_NoBlocking();
						else       	
							u8Val = sysGetChar_NoBlocking();
						if ( u8Val == AVI_START ) // START
						{
							if ( (skpi_key == AVI_NORMAL) && (g_iTarget == UNKNOWN_DEVICE))
							{
								skpi_key = AVI_START;
								g_CommandStatus = CMD_USBMSC | AVI_START;
								return '3';
							}
							else
							{
								u8RetVal = CMD_USBMSC | AVI_START;
								return u8RetVal;	
							}
						}
					}
// command end
				}
			}
		}
	}
#endif	
	return 0XFF;
}

void HighUartPutChar(UINT8 u8CMDSTA, UINT8 u8Status)
{
#if 1	
// 0x5A6B7C8D + command + status
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(0x8D);
	else
		sysPutChar(0x8D);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(0x7C);
	else
		sysPutChar(0x7C);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(0x6B);
	else
		sysPutChar(0x6B);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(0x5A);
	else
		sysPutChar(0x5A);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(u8CMDSTA);
	else
		sysPutChar(u8CMDSTA);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(u8Status);
	else
		sysPutChar(u8Status);	
#else
	
// 0x5A6B7C8D + command + status
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(0x4F);
	else
		sysPutChar(0x4F);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(0x38);
	else
		sysPutChar(0x38);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(0x5A);
	else
		sysPutChar(0x5A);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(0x29);
	else
		sysPutChar(0x29);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(u8CMDSTA);
	else
		sysPutChar(u8CMDSTA);
	if ( g_u32UartType == UART_HIGHSPEED)
		pUART0->UartPutChar(u8Status);
	else
		sysPutChar(u8Status);		
#endif	
}

// UART protocol end

// kpi begin
static void kpi_isr(void)
{	
	UINT32 read0, remTimer;

	gpio_readport(GPIO_PORTB, (unsigned short *)&read0);
//	sysprintf("KPI ISR = %x\n",read0);    
	read0 &= 0x40;
	gpio_cleartriggersrc(GPIO_PORTB);	
	if ( (read0 & 0x40 ) == 0 )
	{
		curTimer = sysGetTicks(TIMER0);
//	sysprintf("Key press\n");
	}
	if ( read0 & 0x40 )
	{
		remTimer = sysGetTicks(TIMER0) - curTimer;

		if ( remTimer <= 60 ) // 0.6 sec
		{
			if ( ( skpi_key == AVI_START ) && ( g_iTarget == AVI_ENCODER ))
			{
				skpi_key = AVI_CAPTURE;
//	sysprintf("AVI capture\n");				
			}
			else
			{
				g_status = STATUS_ERROR;
//	sysprintf("capture error command\n");						
			}
		}		
		else if ( ( remTimer > 60 )  && ( remTimer <= 150 ) )// 0.6 sec ~ 1.2 sec
		{
			if ( ( skpi_key == AVI_NORMAL ) || (skpi_key == AVI_STOP) )
			{
				skpi_key = AVI_START;
				g_iTarget  = AVI_ENCODER;		
//	sysprintf("AVI start \n");						
			}
			else if ( ( skpi_key == AVI_START ) && ( g_iTarget == AVI_ENCODER ))
			{
				skpi_key = AVI_STOP;
//	sysprintf("AVI stop \n");					
			}
			else
			{
				g_status = STATUS_ERROR;
//	sysprintf("AVI error \n");						
			}
		}
		else if ( ( remTimer > 150 )  && ( remTimer <= 250 ) )// 1.5 sec ~ 2.5 sec
		{
			if ( skpi_key == AVI_NORMAL )
			{
				skpi_key = AVI_START;
				g_iTarget  = USB_UVC_UAC;		
				
//	sysprintf("UVC+UAC stop \n");	
//	skpi_key = AVI_NORMAL;
			}
			else
			{
				g_status = STATUS_ERROR;
//  sysprintf("UVC+UAC error \n");					
			}			
		}
		else if ( remTimer > 250 ) // 2.2 sec
		{
			if ( skpi_key == AVI_NORMAL )
			{
				skpi_key = AVI_START;
				g_iTarget  = USB_MSC;		
//	sysprintf("USB mass storage \n");						
//	skpi_key = AVI_NORMAL	;	
			}
			else
			{
				g_status = STATUS_ERROR;
//	sysprintf("USB mass storage error \n");							
			}			
		}		
	}	           
}

int kpi_open(unsigned int src)
{

	gpio_setportdir(GPIO_PORTB,  (1 << 6), 0);
	gpio_setportpull(GPIO_PORTB, (1 << 6) , (1 << 6));	
	gpio_setintmode(GPIO_PORTB, (1 << 6), (1 << 6), (1 << 6) );

	_int = src;

	gpio_setsrcgrp(GPIO_PORTB, (1 << 6), src);

	gpio_setdebounce(256*4, 1 << src);
	gpio_setlatchtrigger(1 << src);
	
	outp32(REG_IRQTGSRC0, 0x00400000);

	sysInstallISR(IRQ_LEVEL_7, (INT_SOURCE_E)src+2, (PVOID)kpi_isr);	
	sysSetInterruptType((INT_SOURCE_E)src+2 , HIGH_LEVEL_SENSITIVE);

	sysSetLocalInterrupt(ENABLE_IRQ);	
	sysEnableInterrupt((INT_SOURCE_E)_int+2);	

	return(0);    
}

void kpi_close(void)
{
	sysDisableInterrupt((INT_SOURCE_E)_int+2);  
	return;
}

// kpi end
	
int main()
{
	UINT32 u32Upll_Clock;
	INT32 g_i32SD0TotalSector;		
	/*Due to I2C share pins with UART, the SerialIO can not be used*/
	int status;
	
	WB_UART_T uart;
	UINT8 u32Item;
	UINT32 u32ExtFreq;
	UINT32 u32Ret;


	memset(pi8UartBuf, 0, 1024);
	u32ExtFreq = sysGetExternalClock();
//Initialize HUART
#ifdef SMALL_BOARD
	register_uart_device(0, &UART0);
  pUART0 = &UART0;
  pUART0->UartPort(0);
	uart.uiFreq = u32ExtFreq*1000;
	uart.uiBaudrate = 115200;
	uart.uiDataBits = WB_DATA_BITS_8;
	uart.uiStopBits = WB_STOP_BITS_1;
	uart.uiParity = WB_PARITY_NONE;
	uart.uiRxTriggerLevel = LEVEL_1_BYTE;
  pUART0->UartInitialize(&uart);
  pUART0->UartEnableInt(UART_INT_NONE);		
  pUART0->UartInstallcallback(0, UartDataValid_Handler);	
  pUART0->UartInstallcallback(1, UartDataTimeOut_Handler);		
#endif
	sysUartPort(1);		

	
	CloseIP();	

	sysSetSystemClock(eSYS_UPLL, 	//E_SYS_SRC_CLK eSrcClk,	
					192000,			//UINT32 u32PllKHz, 	
					192000,			//UINT32 u32SysKHz,
					192000/2,		//UINT32 u32CpuKHz,
					192000/2,		//UINT32 u32HclkKHz,
					  192000/4);	//UINT32 u32ApbKHz									  
					  
	sysEnableCache(CACHE_WRITE_BACK);
	
	/* start timer 0 */
	sysSetTimerReferenceClock(TIMER0, sysGetExternalClock()*1000);
	sysStartTimer(TIMER0, 100, PERIODIC_MODE); 
	
	/* Initial file system */
	fsInitFileSystem();
	
  sysDelay(200); 	
	
	kpi_open(3); // use nIRQ0 as external interrupt source
	
	DBG_PRINTF("================================================================\n");
	DBG_PRINTF("Please select the target								\n");    	
	DBG_PRINTF("================================================================\n");	    	
	sCurNo = 1;	
	u32Ret = STATUS_SUCCESS;
loop1:	
	if ( u32Ret != STATUS_SUCCESS )
	{
		WarningLED();
	}
	u32Ret = STATUS_SUCCESS;	
	g_iTarget = UNKNOWN_DEVICE;
	skpi_key = AVI_NORMAL;	
	g_u32UartType = UART_HIGHSPEED;
	//g_u32UartType = UART_NORMAL;
	do
	{    
		DBG_PRINTF("================================================================\n");
		DBG_PRINTF(" [1] AVI Encoder										\n");	
		DBG_PRINTF(" [2] USB UVC+UAC 									\n");		
		DBG_PRINTF(" [3] USB MSC    									\n");					
		DBG_PRINTF("================================================================\n");

		while (1)
		{

			u32Item = HighUartGetChar();
			if ( (u32Item == '1') || (u32Item == '2') || (u32Item == '3'))
			{
				sysprintf("Select %c\n",u32Item);					
				break;
			}
			else if ( u32Item != 0xFF )
			{
				//command error
				HighUartPutChar(u32Item, STATUS_ERRORCMD);	
				u32Ret = STATUS_ERRORCMD;
			}
// Key in			
			if ( skpi_key == AVI_START )
			{
				if (g_iTarget == USB_UVC_UAC)
					u32Item = '2';
				else if (g_iTarget  == USB_MSC )
					u32Item = '3';
				else if ( g_iTarget == AVI_ENCODER )
					u32Item = '1';
				else
					continue;
				sysprintf("Key in select %c\n",u32Item);							
				break;
			}
		}
		
		if ( u32Item == '1' )
		{
			g_iTarget  = AVI_ENCODER;
			break;
		}   
		
 		if ( u32Item == '2' )
		{
			g_iTarget = USB_UVC_UAC;
			break;
		}   
		
 		if ( u32Item == '3' )
		{
			g_iTarget = USB_MSC;
			break;
		}   
	}while (1);
	
	if ( g_iTarget == USB_MSC )
	{
		udcOpen();		 
		sicIoctl(SIC_SET_CLOCK, 192000, 0, 0);		
		sicOpen();
 		status = sicSdOpen0();
		if(status < 0)
		{
			sicSdClose0();		
			sysprintf("SD card fails\n");			
			HighUartPutChar(g_CommandStatus, STATUS_ERRORSD);
			u32Ret = STATUS_ERRORSD;
			goto loop1;
		}
		mscdInit();
		mscdFlashInit(NULL,status);				
		udcInit();
// check USB plug in or out
		if ( PlugDetection() == TRUE )
		{
			HighUartPutChar(g_CommandStatus, STATUS_SUCCESS);
		}
		else
		{
			HighUartPutChar(g_CommandStatus, STATUS_ERRORUSB);
			u32Ret = STATUS_ERRORUSB;
		}
// check USB plug in or out
		mscdMassEvent(PlugDetection);	

		mscdDeinit();	
		udcDeinit();	
		udcClose();
		
		sicClose();		
		goto loop1;
	}
	
   status = 0;  // ok
#if 0  // Close	
	do
	{    
		DBG_PRINTF("================================================================\n");
		DBG_PRINTF(" [1] NT99050 demo - 640X480										\n");	
		DBG_PRINTF(" [2] GC0308 demo - 640X480										\n");			
		DBG_PRINTF(" [3] NT99141 demo - 1280X720									\n");				
		DBG_PRINTF(" [4] Exit																			\n");			
		DBG_PRINTF("================================================================\n");

		if ( g_u32UartType == UART_HIGHSPEED)	
   			u32Item = pUART0->UartGetChar();		
		else
			u32Item = sysGetChar();	
//sysprintf("Select %c\n",u32Item);				
		if ( u32Item == '1' )
		{
			iSensorResolution = VGA_NT99050;
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
		   break;
		}   
		
	  	if ( u32Item == '2' )
		{
			iSensorResolution = VGA_GC0308;
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
		   break;
		}   

	  	if ( u32Item == '3' )
		{
			iSensorResolution = HD_NT99141;
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
		   break;
		}   
		if ( u32Item == '4' )
		{
			if ( g_u32UartType == UART_HIGHSPEED)	
				pUART0->UartPutChar(ch2);
			goto loop1;
		}   
	}while (1);
#endif
	iSensorResolution = VGA_GC0308;	
	
	u32PacketFrameBuffer0 = ((UINT32) u8FrameBuffer0 | 0x80000000); // + BITSTREAM_OFFSET; 
	u32PacketFrameBuffer1 = ((UINT32) u8FrameBuffer1 | 0x80000000); // + BITSTREAM_OFFSET; 
	u32BitstreamBuffer0 = ((UINT32)u8BitstreamBuffer0| 0x80000000)+8;
		
// UVC + UAC		
	if (g_iTarget == USB_UVC_UAC)
	{
#if 0		
		if (iSensorResolution == VGA_NT99050)		
		{
			uavcdSetResolution(0);  // set VGA
			OPT_STRIDE=640;  
			OPT_CROP_WIDTH=	640; 
			OPT_CROP_HEIGHT=480;   
			OPT_PREVIEW_WIDTH=640; 
			OPT_PREVIEW_HEIGHT=480;  
			OPT_ENCODE_WIDTH =640;
			OPT_ENCODE_HEIGHT=480;	
			g_u16FixedWidth = u16CurWidth =640;
			g_u16FixedHeight = u16CurHeight=480;
			register_sensor(&SensorIQ);			
			gbMT99050 = TRUE;			
			if ( Smpl_NT99050((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail )
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				goto again;						
			}
			else
			{
				sysprintf("Sensor NT99050 is OK\n");
			}							
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MIN = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MAX = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_DEF = 0;
			uvcPuInfo.PU_BRIGHTNESS_MIN = 0;
			uvcPuInfo.PU_BRIGHTNESS_MAX = 255;
			uvcPuInfo.PU_BRIGHTNESS_DEF = SensorIQ.IQ_GetBrightness();
			uvcPuInfo.PU_CONTRAST_MIN = 0;
			uvcPuInfo.PU_CONTRAST_MAX = 255;
			uvcPuInfo.PU_CONTRAST_DEF = SensorIQ.IQ_GetContrast();
			uvcPuInfo.PU_HUE_MIN = 0;
			uvcPuInfo.PU_HUE_MAX = 255;
			uvcPuInfo.PU_HUE_DEF = SensorIQ.IQ_GetHue();
			uvcPuInfo.PU_SATURATION_MIN = 0;
			uvcPuInfo.PU_SATURATION_MAX = 0;
			uvcPuInfo.PU_SATURATION_DEF = 0;
			uvcPuInfo.PU_SHARPNESS_MIN = 0;
			uvcPuInfo.PU_SHARPNESS_MAX =255;
			uvcPuInfo.PU_SHARPNESS_DEF = SensorIQ.IQ_GetSharpness();
			uvcPuInfo.PU_GAMMA_MIN = 0;
			uvcPuInfo.PU_GAMMA_MAX = 0;
			uvcPuInfo.PU_GAMMA_DEF = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MIN = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MAX = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_DEF = 0; 	
		}
		else if (iSensorResolution == VGA_GC0308)
#endif			
		{
			uavcdSetResolution(0);  // set VGA
			OPT_STRIDE=640;  
			OPT_CROP_WIDTH=	640; 
			OPT_CROP_HEIGHT=480;   
			OPT_PREVIEW_WIDTH=640; 
			OPT_PREVIEW_HEIGHT=480;  
			OPT_ENCODE_WIDTH =640;
			OPT_ENCODE_HEIGHT=480;	
			g_u16FixedWidth = u16CurWidth =640;
			g_u16FixedHeight = u16CurHeight=480;
			if (Smpl_GC0308((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				HighUartPutChar(g_CommandStatus, STATUS_ERRORSENSOR);
				u32Ret = STATUS_ERRORSENSOR;
				goto loop1; //again;
			}			
			else
			{
				sysprintf("Sensor GC0308 is OK\n");
			}			
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MIN = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MAX = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_DEF = 0;
			uvcPuInfo.PU_BRIGHTNESS_MIN = 0;
			uvcPuInfo.PU_BRIGHTNESS_MAX = 255;
			uvcPuInfo.PU_BRIGHTNESS_DEF = 128; //SensorIQ.IQ_GetBrightness();
			uvcPuInfo.PU_CONTRAST_MIN = 0;
			uvcPuInfo.PU_CONTRAST_MAX = 255;
			uvcPuInfo.PU_CONTRAST_DEF = 128; //SensorIQ.IQ_GetContrast();
			uvcPuInfo.PU_HUE_MIN = 0;
			uvcPuInfo.PU_HUE_MAX = 255;
			uvcPuInfo.PU_HUE_DEF = 128; //SensorIQ.IQ_GetHue();
			uvcPuInfo.PU_SATURATION_MIN = 0;
			uvcPuInfo.PU_SATURATION_MAX = 0;
			uvcPuInfo.PU_SATURATION_DEF = 0;
			uvcPuInfo.PU_SHARPNESS_MIN = 0;
			uvcPuInfo.PU_SHARPNESS_MAX =255;
			uvcPuInfo.PU_SHARPNESS_DEF = 128; //SensorIQ.IQ_GetSharpness();
			uvcPuInfo.PU_GAMMA_MIN = 0;
			uvcPuInfo.PU_GAMMA_MAX = 0;
			uvcPuInfo.PU_GAMMA_DEF = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MIN = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MAX = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_DEF = 0; 
		}
#if 0		
		else if (iSensorResolution == HD_NT99141)
		{
			uavcdSetResolution(1);  // set HD				
			OPT_STRIDE=1280;  
			OPT_CROP_WIDTH=	1280; 
			OPT_CROP_HEIGHT=720;   
			OPT_PREVIEW_WIDTH=1280; 
			OPT_PREVIEW_HEIGHT=720;  
			OPT_ENCODE_WIDTH =1280;
			OPT_ENCODE_HEIGHT=720;	
			g_u16FixedWidth = u16CurWidth =1280;
			g_u16FixedHeight = u16CurHeight=720;	
			if ( Smpl_NT99141_HD((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)				
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				goto again;	
			}			
			else
			{
				sysprintf("Sensor NT99141 is OK\n");			
			}
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MIN = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_MAX = 0;
			uvcPuInfo.PU_BACKLIGHT_COMPENSATION_DEF = 0;
			uvcPuInfo.PU_BRIGHTNESS_MIN = 0;
			uvcPuInfo.PU_BRIGHTNESS_MAX = 255;
			uvcPuInfo.PU_BRIGHTNESS_DEF = 128; //SensorIQ.IQ_GetBrightness();
			uvcPuInfo.PU_CONTRAST_MIN = 0;
			uvcPuInfo.PU_CONTRAST_MAX = 255;
			uvcPuInfo.PU_CONTRAST_DEF = 128; //SensorIQ.IQ_GetContrast();
			uvcPuInfo.PU_HUE_MIN = 0;
			uvcPuInfo.PU_HUE_MAX = 255;
			uvcPuInfo.PU_HUE_DEF = 128; //SensorIQ.IQ_GetHue();
			uvcPuInfo.PU_SATURATION_MIN = 0;
			uvcPuInfo.PU_SATURATION_MAX = 0;
			uvcPuInfo.PU_SATURATION_DEF = 0;
			uvcPuInfo.PU_SHARPNESS_MIN = 0;
			uvcPuInfo.PU_SHARPNESS_MAX =255;
			uvcPuInfo.PU_SHARPNESS_DEF = 128; //SensorIQ.IQ_GetSharpness();
			uvcPuInfo.PU_GAMMA_MIN = 0;
			uvcPuInfo.PU_GAMMA_MAX = 0;
			uvcPuInfo.PU_GAMMA_DEF = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MIN = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_MAX = 0;
			uvcPuInfo.PU_POWER_LINE_FREQUENCY_DEF = 0; 	
		}
#endif
		jpegOpen ();    
		uavc_main();					
		jpegClose(); 	
		videoIn_Close();			
		goto loop1;			
	}

	while(1) {
#if 0		
		while (1) {
			DBG_PRINTF("\nCamera status \n");
			DBG_PRINTF(" [1] Normal photography \n");
			DBG_PRINTF(" [2] Time lapse photography \n");	
			DBG_PRINTF(" [3] Exit    \n");						
			if ( g_u32UartType == UART_HIGHSPEED)
				skey = pUART0->UartGetChar();	
			else
				skey = sysGetChar();
//sysprintf("Select %c\n",skey);					
			if ( skey == '1')
			{
				bVideo_Only = FALSE;
				DBG_PRINTF(" Select [1] \n");			
				break;
			}
			else if ( skey == '2')
			{
				bVideo_Only = TRUE;
				WITHOUT_AUDIO_TIME= 1; // 1 seconds
				DBG_PRINTF(" Select [2] \n");			
				break;
			}
			else if ( skey == '3')
			{
				goto loop1;
			}						
		}
#endif		
#ifdef SMALL_BOARD		
		outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20);	//GPIOA-5 output. 
		outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x20);	//GPIOA-5 output LOW. 
#endif	
	{
		status = 0;
		skey = 0xFF;
		sysprintf("Start Record\n");
		sysprintf("Press 1 to stop, 2 to capture one image !\n");
	/*-----------------------------------------------------------------------*/
	/*  Init SD card                                                       			*/
	/*-----------------------------------------------------------------------*/
		u32Upll_Clock = sysGetPLLOutputKhz(eSYS_UPLL, sysGetExternalClock());
		sicIoctl(SIC_SET_CLOCK, u32Upll_Clock, 0, 0);
		sicOpen();
		g_i32SD0TotalSector = sicSdOpen0();	/* Total sector or error code */
		sysprintf("SD total size = %8x\n", g_i32SD0TotalSector);
		if(g_i32SD0TotalSector < 0)
		{
			sysprintf("no SD card or SD card fail\n");
			sysprintf("\nPlease insert SD card\n");
//      sicSdClose0();
			HighUartPutChar(g_CommandStatus, STATUS_ERRORSD);
			u32Ret = STATUS_ERRORSD;
			goto sd_fail;            	
		}
		fsAssignDriveNumber('C', DISK_TYPE_SD_MMC, 0, 1);
#if 0		
		if ( iSensorResolution == VGA_NT99050 )
		{
			OPT_STRIDE=640;  
			OPT_CROP_WIDTH=	640; 
			OPT_CROP_HEIGHT=480;   
			OPT_PREVIEW_WIDTH=320; 
			OPT_PREVIEW_HEIGHT=240;  
			OPT_ENCODE_WIDTH =640;
			OPT_ENCODE_HEIGHT=480;	
			u16CurWidth =640;
			u16CurHeight=480;
			s_i32FrameRate = 30;			
			register_sensor(&SensorIQ);			
			if ( Smpl_NT99050((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail )
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				status = 1;
				goto sd_fail;
			}
			else
			{
				sysprintf("Sensor NT99050 is OK\n");
			}
		}   
		else if ( iSensorResolution == VGA_GC0308)
#endif			
		{
			OPT_STRIDE=640;  
			OPT_CROP_WIDTH=	640; 
			OPT_CROP_HEIGHT=480;   
			OPT_PREVIEW_WIDTH=320; 
			OPT_PREVIEW_HEIGHT=240;  
			OPT_ENCODE_WIDTH =640;
			OPT_ENCODE_HEIGHT=480;	
			u16CurWidth =640;
			u16CurHeight=480;
			s_i32FrameRate = 30;			
			if (Smpl_GC0308((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				status = 1;
				HighUartPutChar(g_CommandStatus, STATUS_ERRORSENSOR);
				u32Ret = STATUS_ERRORSENSOR;
				goto sd_fail;
			}
			else
			{
				sysprintf("Sensor GC0308 is OK\n");
			}								
		}
#if 0		
		else if ( iSensorResolution == HD_NT99141 )
		{
			OPT_STRIDE=1280;  
			OPT_CROP_WIDTH=	1280; 
			OPT_CROP_HEIGHT=720;   
			OPT_PREVIEW_WIDTH=320; 
			OPT_PREVIEW_HEIGHT=240;  
			OPT_ENCODE_WIDTH =1280;
			OPT_ENCODE_HEIGHT=720;	
			u16CurWidth =1280;
			u16CurHeight=720;
			s_i32FrameRate = 20;						
			if ( Smpl_NT99141_HD((PUINT8)u32PacketFrameBuffer0,(PUINT8)NULL) == Fail)
			{
				sysprintf("Sensor fail !\n");
				sysprintf("Please check the sensor !\n");
				status = 1;
				goto sd_fail;	
			}			
			else
			{
				sysprintf("Sensor NT99141 is OK\n");
			}
		}
#endif		
// pass success to device
		HighUartPutChar(g_CommandStatus, STATUS_SUCCESS);
// pass success to device

		jpegOpenEx (NULL, JpegEncoderCallback); 
		if ( AVIEnc_main() < 0 )
		{
// file system issue, flash for 8 seconds
			WarningLED();
		}	
		jpegClose(); 	
		sCurNo++;		
sd_fail:	
		videoIn_Close();
		sicSdClose0();
		sicClose();			
	}       
//	if ( status == 1 )
    	goto loop1; //again;
	}	// while
	
	kpi_close();	

	sysStopTimer(TIMER0);
	sysDisableCache();
    
	return 0;
} /* end main */
