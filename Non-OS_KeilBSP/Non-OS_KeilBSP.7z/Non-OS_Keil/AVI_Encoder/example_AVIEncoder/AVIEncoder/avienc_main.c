#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wbio.h"
#include "wblib.h"
#include "w55fa93_reg.h"
#include "w55fa93_sic.h"
#include "demo.h"
#include "jpegcodec.h"
#include "W55FA93_VideoIn.h"
#include "AviLib.h"
#include "nvtfat.h"

#define PCM					0
#define IMAADPCM			1


#define TIME_NO			120

extern int WITHOUT_AUDIO_TIME;
extern BOOL bVideo_Only;

extern int InitializeUAC(UINT32 u32SampleRate);
extern void StartUAC(void);
extern void StopUAC(void);
extern int GetPCMSampleData(PINT16 pi16PCM, INT32 u32SampleCount);

void JpegEncoderCallback(UINT32 u32ImageSize);
void jpegPre();

INT32 i32CurTimer;

UINT32 volatile skey;

/* Buffer for Packet & Planar format */
UINT8 __align(32) u8FrameBuffer0[1280*720*3/2]; 	
UINT8 __align(32) u8FrameBuffer1[1280*720*3/2];


	
#define ENCODE_BUFFERNO 	2
#define JPEG_BUFFERNO		15     //15
#define MAX_JPEG_SIZE		0x20000//0xC800


UINT8 __align(32) u8BitstreamBuffer0[MAX_JPEG_SIZE*JPEG_BUFFERNO]; 
UINT8 __align(32) g_pbySnapBuffer[0x20000];

UINT8  volatile BufStatus[ENCODE_BUFFERNO];   // 0 is empty, 1 is full, 2 is processing.
UINT32 jpeg_mid, jpeg_out,jpeg_in, jpeg_final;  
UINT32    vid_in, vid_out; 

UINT8  volatile JpegStatus[JPEG_BUFFERNO];   // 0 is empty, 1 is full, 2 is processing.

UINT32 u32PacketFrameBuffer0, u32PacketFrameBuffer1,u32BitstreamBuffer0,u32BitstreamBuffer1;

/* Current Buffer Address for JPEG Encode */
UINT32 u32CurBitstreamAddress[JPEG_BUFFERNO];
UINT32 u32JPEGSize[JPEG_BUFFERNO];
UINT8  volatile EncodeStatus[JPEG_BUFFERNO];   // 0 is empty, 1 is full, 2 is processing.

void AVIEncEvent(void);

/* Current Width & Height */
extern UINT16 u16CurWidth, u16CurHeight;
//UINT16 u16CurWidth = 640, u16CurHeight = 480;
//INT32	s_i32FrameRate = 30;  //30
extern INT32	s_i32FrameRate;  //30
INT32   s_i32Type = PCM; //IMAADPCM;   // PCM
INT32   s_i32SampleRate = 16000;
/* audio buffer */

MV_CFG_T tMvCfg;
INT16 *g_i16RecBuf;
INT32 g_i32RecSize;

extern INT16 *g_pi16AudioBuf;
extern int IN_DATA_BUF_NUM;
extern INT32 s_i16RecInSample;
extern INT32 s_i16RecOutPos;
extern UINT8 bPlaying;

extern int sCurNo;

int volatile   g_runavi=0;
INT volatile last_time;
INT	last_vid_frame;
CHAR	g_suRecorderFile[40];	

UINT32 u32VideoInIdx;

// JPEG quantitation table
UINT8      g_au8QTableUser0[64], g_au8QTableUser1[64];

UINT8      g_au8QTableStd0[64] = {16,  11,  10,  16,  24,  40,  51,  61,
                                                        12,  12,  14,  19,  26,  58,  60,  55,
                                                        14,  13,  16,  24,  40,  57,  69,  56,
                                                        14,  17,  22,  29,  51,  87,  80,  62,
                                                        18,  22,  37,  56,  68, 109, 103,  77, 
                                                        24,  35,  55,  64,  81, 104, 113,  92,
                                                        49,  64,  78,  87, 103, 121, 120, 101,
                                                        72,  92,  95,  98, 112, 100, 103,  99},
                g_au8QTableStd1[64] = {17,  18,  24,  47,  99,  99,  99,  99,
                                                        18,  21,  26,  66,  99,  99,  99,  99,            
                                                        24,  26,  56,  99,  99,  99,  99,  99,            
                                                        47,  66,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99},
                g_au8QTableStd2[64] = {17,  18,  24,  47,  99,  99,  99,  99,
                                                        18,  21,  26,  66,  99,  99,  99,  99,            
                                                        24,  26,  56,  99,  99,  99,  99,  99,            
                                                        47,  66,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99,
                                                        99,  99,  99,  99,  99,  99,  99,  99};   


//#define 	UVC_SKIP_FRAME		4
//UINT32      u32SkipFrame = 0;

extern UARTDEV_T* pUART0;



void JpegEncoderCallback(UINT32 u32ImageSize)
{
    BufStatus[vid_out] = 0;
    vid_out++;
	if ( vid_out == ENCODE_BUFFERNO )
	    vid_out = 0;  
	           
    u32JPEGSize[jpeg_mid] = u32ImageSize;
 	EncodeStatus[jpeg_mid] = 1; 
//sysprintf("jpeg isr %d\n", jpeg_mid); 	 
 	jpeg_mid++;
    if ( jpeg_mid == JPEG_BUFFERNO )
      jpeg_mid = 0;     	    
    
}

int audioSetBuffer(MV_CFG_T *ptMvCfg, UINT8 *pucPcmBuff, INT puFrameSize)
{

    INT32 i32SampleCount;
	
    if ( ptMvCfg == NULL )	
    {
    	g_pi16AudioBuf = (INT16 *)pucPcmBuff;
    	IN_DATA_BUF_NUM = puFrameSize >> 1;
    	return 0;
    }
    else if ( ptMvCfg == (MV_CFG_T *)1 ) // Get the unused data
    {
    	return ((s_i16RecInSample << 1));
    }
    else if ( ptMvCfg == (MV_CFG_T *)2 ) // Get the pointer of Buffer, and
    {
   	i32SampleCount = puFrameSize >> 1; // 2 bytes
   	    while ( GetPCMSampleData( (PINT16)pucPcmBuff,i32SampleCount) == 0 )
   	    {
   	    ;
   	    }
    	return ((INT32)pucPcmBuff);     	
    }
    return 0;
}
void  audioStartRecord(MV_CFG_T *ptMvCfg)
{
    if ( ptMvCfg == NULL )
    {	
	  	 g_runavi = 1;    
//sysprintf("start audio\n");	  	 
    	InitializeUAC(s_i32SampleRate);  // Sample rate = 16000KHz
    	StartUAC();	
    }
    else if ( ptMvCfg ==(MV_CFG_T *)1 )   // Set flags
    {
        last_time = sysGetTicks(TIMER0);  // begin record
    	bPlaying = TRUE;	

    }
    
}

void  audioStopRecord(MV_CFG_T *ptMvCfg)
{
    StopUAC(); 
}

VOID  media_record_callback(MV_CFG_T *ptMvCfg)
{
	MV_INFO_T 		*ptMvInfo;


	
	mflGetMovieInfo(ptMvCfg, &ptMvInfo);

	if (sysGetTicks(TIMER0) - last_time > 100)
	{
		if ( bVideo_Only == TRUE )
		{
		sysprintf(" (Vid #%d - %d) \n",
			    ptMvInfo->uVidTotalFrames, ptMvInfo->uVidTotalFrames - last_vid_frame);		
		}
		else
		{
		sysprintf("T=%d.%02d  (Vid #%d - %d) (Audio #%d) \n",
				ptMvInfo->uMovieLength / 100, ptMvInfo->uMovieLength % 100,
			    ptMvInfo->uVidTotalFrames, ptMvInfo->uVidTotalFrames - last_vid_frame, s_i16RecInSample);
		}	

		last_time = sysGetTicks(TIMER0);
		last_vid_frame = ptMvInfo->uVidTotalFrames;
//		last_au_frame  = ptMvInfo->uAuTotalFrames;

       	i32CurTimer++;
       	if ( i32CurTimer >= TIME_NO )
       	{
			mflRecControl(ptMvCfg, REC_CTRL_STOP, 0);
       	} 


#ifdef ARDUINO			
   		skey = pUART0->UartGetChar_NoBlocking();			
#else       	
		skey = sysGetChar_NoBlocking();
#endif
//		if ( skey == 1 )
		if ( skey == '1' )
		{
#ifdef ARDUINO		
       		pUART0->UartPutChar(0x39);   		
#endif           
		   	sysprintf("Stop record\n");
		   	mflRecControl(ptMvCfg, REC_CTRL_STOP, 0);		   
    	}      
	}
#if 0	
	if ( skey == '2' ) //start snapshot
	{
#ifdef ARDUINO		
   		pUART0->UartPutChar(0x39);   		
#endif      	   
		mflRecControl(ptMvCfg, REC_CTRL_SNAPSHOT, 0);	
		skey = 0xFF;
		   
	}
#endif	

}

INT mjpeg_init_encode(UINT8 *pucM4VHeader, UINT32 *puHeaderSize,BOOL bIsH263, UINT16 usImageWidth, UINT16 usImageHeight)
{
    *puHeaderSize = 0;
    return 0;
}


INT  mjpeg_encode_frame(PUINT8 *pucFrameBuff, UINT32 *puFrameSize)
{
     while (EncodeStatus[jpeg_out] == 0 );
//   sysprintf("jpeg encoded finished\n");    
	 *puFrameSize = u32JPEGSize[jpeg_out];
				/* Set Address */
	 *pucFrameBuff = (PUINT8)((UINT32)u32CurBitstreamAddress[jpeg_out]);	
//	 if ( *puFrameSize >= 0x10000 )
//	      sysprintf("Encoder size %x\n", *puFrameSize); 
	 EncodeStatus[jpeg_out] = 0;	 
	 jpeg_out++;
	 if ( jpeg_out == JPEG_BUFFERNO )
	    jpeg_out = 0;    
   return 0;
}

void mjpeg_rec_frame_done(PUINT8 *pucFrameBuff)
{
	 *pucFrameBuff = (PUINT8)((UINT32)g_pbySnapBuffer);	
 	 JpegStatus[jpeg_final] = 0; 
	 jpeg_final++;
	 if ( jpeg_final == JPEG_BUFFERNO )
	    jpeg_final = 0;           
}


void AVIEncOpen(void)
{

	INT i;
	char szFileName[20];
    INT nStatus;

    last_vid_frame = 0;
    jpegPre();    

	sprintf(szFileName, "C:\\smpl%04d.avi", sCurNo);	
	sysprintf("encoded file = %s\n", szFileName);
   	fsAsciiToUnicode(szFileName, g_suRecorderFile, TRUE);		
 	fsDeleteFile(g_suRecorderFile, NULL);



    g_runavi = 0;   
	tMvCfg.eOutMediaType   = MFL_MEDIA_AVI;
        if ( s_i32Type == PCM )
		tMvCfg.eAuCodecType    = MFL_CODEC_PCM;
	else
		tMvCfg.eAuCodecType    = MFL_CODEC_ADPCM;	
	
	tMvCfg.eVidCodecType   = MFL_CODEC_JPEG;

	tMvCfg.eOutStrmType    = MFL_STREAM_FILE;
	tMvCfg.suOutMediaFile  = g_suRecorderFile;
	tMvCfg.szOMFAscii      = NULL;
	tMvCfg.suOutMetaFile   = NULL;
	tMvCfg.szOTFAscii      = NULL;
	tMvCfg.bUseTempFile    = TRUE;

	if ( bVideo_Only == TRUE )
		tMvCfg.bIsRecordAudio  = FALSE;	
   	else
		tMvCfg.bIsRecordAudio  = TRUE;
	
	tMvCfg.nAudioRecVolume = 8; //_nAudioVolume;
		//tMvCfg.eAudioRecDevice = MFL_REC_I2S;
	tMvCfg.eAudioRecDevice = MFL_REC_ADC;
	tMvCfg.eAuRecSRate     = s_i32SampleRate;  //AU_SRATE_16000;   // Sample Rate
	tMvCfg.nVidRecIntraIntval = 30;
        if ( s_i32Type == PCM )	
		tMvCfg.nAuRecChnNum    = 1;
        else
 		tMvCfg.nAuRecChnNum    = 2;       		
	tMvCfg.uAuBuffSizeDB   = 32 * 1024;
#ifdef SILENCE
	tMvCfg.uAuRecAvgBitRate = 0; //no audio
	tMvCfg.uAuRecMaxBitRate = 0; //no audio 
#else		
	tMvCfg.uAuRecAvgBitRate = 256000;
	tMvCfg.uAuRecMaxBitRate = 256000;
#endif
	tMvCfg.bIsRecordVideo  = TRUE;
	tMvCfg.nVidRecFrate    = s_i32FrameRate;     // Video Frame Rate
	tMvCfg.sVidRecWidth    = u16CurWidth;
	tMvCfg.sVidRecHeight   = u16CurHeight;
	tMvCfg.uVidBuffSizeDB  = 128 * 1024;
	tMvCfg.uVidRecAvgBitRate = 128000* s_i32FrameRate*2;
	tMvCfg.uVidRecMaxBitRate = 256000*s_i32FrameRate*2 ;
	if ( bVideo_Only == TRUE )	
		tMvCfg.param1		   = (MV_CFG_T *)((((UINT32)JPEG_BUFFERNO) << 28)|((UINT32)WITHOUT_AUDIO_TIME <<16)|TIME_NO); //(10 * idx);
	else	
		tMvCfg.param1		   = (MV_CFG_T *)((((UINT32)JPEG_BUFFERNO) << 28)|TIME_NO); //(10 * idx);

	tMvCfg.ap_time         = media_record_callback;
	tMvCfg.vid_init_encode = mjpeg_init_encode;
	tMvCfg.vid_enc_frame   = mjpeg_encode_frame;
	tMvCfg.vid_rec_frame_done = mjpeg_rec_frame_done;
	
	
	tMvCfg.au_on_start     = audioStartRecord;
	tMvCfg.au_on_stop      = audioStopRecord;
	tMvCfg.au_sbc_encode   = audioSetBuffer;
		
	i32CurTimer = 0;

    for (i=0; i< ENCODE_BUFFERNO; i++)
    {
        BufStatus[i] = 0;
    }
    for (i=0; i<JPEG_BUFFERNO; i++)
    {    
        EncodeStatus[i] = 0;   
        JpegStatus[i] = 0;
    }                
    
     vid_in = 0;
     vid_out = 0; 
     jpeg_out = 0;      
     jpeg_mid = 0;     
     jpeg_in=0;
     jpeg_final = 0;
	 u32VideoInIdx = 0;       

    last_vid_frame = 0;

   	
	if ( bVideo_Only == TRUE )
		g_runavi = 1; 	
	 
	nStatus = mflMovieMaker(&tMvCfg);
	if (nStatus < 0)
	{ 
		sysprintf("Record error = %x\n", nStatus); 
		skey = 16; 		 
	}
   	 g_runavi = 0;
/*   	 
// 	outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20);	//GPIOA-5 output. 
	outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x20);	//GPIOA-5 output LOW. 
	*/
	sysprintf("AVI record done.\n");	
   	 
}


/* AVI Encoder Main */
#if 1
void AVIEnc_main(void)
{
    INT nStatus;
    
    last_vid_frame = 0;
//    last_au_frame = 0;
	/* Open AVI encoder Device */

    AVIEncOpen();
/*   
	nStatus = mflMovieMaker(&tMvCfg);
	if (nStatus < 0)
	{ 
		sysprintf("Record error = %x\n", nStatus);  
	};

   	 g_runavi = 0;
// 	outp32(REG_GPIOA_OMD, inp32(REG_GPIOA_OMD) | 0x20);	//GPIOA-5 output. 
	outp32(REG_GPIOA_DOUT, inp32(REG_GPIOA_DOUT) & ~0x20);	//GPIOA-5 output LOW. 
	sysprintf("AVI record done.\n");   	    
	*/
}

#endif
/* UVC event */

/* Change VideoIN Buffer when Frame End */

void VideoIn_InterruptHandler(void)
{

	switch(u32VideoInIdx)
	{
		case 0:		
		/* Change frame buffer 1 if Frame Buffer 1 is clean, Otherwise, do nothing */
		if ( g_runavi == 1 )
		{					
		if ( ( BufStatus[1] == 0  ) && ( JpegStatus[jpeg_in] == 0 ))
		{
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,				
				0, 							//0 = Planar Y buffer address
				u32PacketFrameBuffer1 );							
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				1, 							//1 = Planar U buffer address
				u32PacketFrameBuffer1 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT);							
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				2, 							//2 = Planar V buffer address
				u32PacketFrameBuffer1 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT+OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT/4 );																					
			u32VideoInIdx = 1; 				
			BufStatus[vid_in] = 1; 
                    	vid_in++;
                    	if ( vid_in == ENCODE_BUFFERNO )
                       		vid_in = 0;
                       	u32CurBitstreamAddress[jpeg_in] = ((UINT32)u32BitstreamBuffer0+ MAX_JPEG_SIZE*jpeg_in);                       
                   	jpegEncode((UINT32)u32PacketFrameBuffer0,(UINT32)u32CurBitstreamAddress[jpeg_in], u16CurWidth,u16CurHeight);
			JpegStatus[jpeg_in] = 1;
			jpeg_in++;                       
                    	if ( jpeg_in == JPEG_BUFFERNO )
				jpeg_in = 0;  
//sysprintf("Video 0 = %d\n", jpeg_in);                         
       
		}
        	}					
		break; 	 				
		case 1:	
		if ( g_runavi == 1 )
		{					
                if ( ( BufStatus[0] == 0  ) && ( JpegStatus[jpeg_in] == 0 ))
		{
 			/* Set Planar Buffer Address */						
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,				
				0, 							//0 = Planar Y buffer address
				u32PacketFrameBuffer0 );							
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				1, 							//1 = Planar U buffer address
				u32PacketFrameBuffer0 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT);							
			videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				2, 							//2 = Planar V buffer address
				u32PacketFrameBuffer0 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT+OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT/4 );
			u32VideoInIdx = 0;	
 
			BufStatus[vid_in] = 1;   
                    	vid_in++;
                    	if ( vid_in == ENCODE_BUFFERNO )
				vid_in = 0;
                       
			u32CurBitstreamAddress[jpeg_in] = ((UINT32)u32BitstreamBuffer0+ MAX_JPEG_SIZE*jpeg_in);                       
                   	jpegEncode((UINT32)u32PacketFrameBuffer1,(UINT32)u32CurBitstreamAddress[jpeg_in], u16CurWidth,u16CurHeight);
			JpegStatus[jpeg_in] = 1;                   	
			jpeg_in++;                       
                    	if ( jpeg_in == JPEG_BUFFERNO )
        			jpeg_in = 0;    
//sysprintf("Video 1 = %d\n", jpeg_in);                         
             	}
		}
		break; 	 	
	}    		
}



void jpegAdjustUserQTAB(PUINT8 puQTableSrc, PUINT8 puQTableDest, int factor)
{
        int i, temp;      
        if (factor <= 0) factor = 1;
        if (factor > 100) factor = 100;

        if (factor < 50)
              factor = 5000 / factor;
        else
              factor = 200 - factor * 2;

        for (i = 0; i < 64; i++)
        {
                temp = ((long) puQTableSrc[i] * (long) factor + (long)50) / (long)100;
                /* limit the values to the valid range */
                if (temp <= 0) temp = 1;
                if (temp > 255)
                temp = 255L; /* limit to baseline range if requested */
                puQTableDest[i] = (UINT8) temp;
        }
}


/* JPEG Encode function */
UINT32 jpegEncode(UINT32 u32YAddress,UINT32 u32BitstreamAddress, UINT16 u16Width,UINT16 u16Height)
//UINT32 jpegEncode(UINT32 u32BitstreamAddress)
{
		/* JPEG Init */
	jpegInit();	
			
		/* Set Source Y/U/V Stride */	       
	jpegIoctl(JPEG_IOCTL_SET_YSTRIDE, u16Width, 0);	   
	jpegIoctl(JPEG_IOCTL_SET_USTRIDE, u16Width/2, 0);
	jpegIoctl(JPEG_IOCTL_SET_VSTRIDE, u16Width/2, 0);			

	   	/* Set Source Address */	
	jpegIoctl(JPEG_IOCTL_SET_YADDR, u32YAddress, 0);
   	jpegIoctl(JPEG_IOCTL_SET_UADDR, (u32YAddress + u16Width * u16Height), 0);   		
	jpegIoctl(JPEG_IOCTL_SET_VADDR, (u32YAddress + u16Width*u16Height+u16Width*u16Height/4), 0);	
								
	    /* Set Bit stream Address */   
	jpegIoctl(JPEG_IOCTL_SET_BITSTREAM_ADDR, u32BitstreamAddress, 0);
	    	
		/* Encode mode, encoding primary image, YUV 4:2:0 */
	//jpegIoctl(JPEG_IOCTL_SET_ENCODE_MODE, JPEG_ENC_SOURCE_PACKET, JPEG_ENC_PRIMARY_YUV422);		
        jpegIoctl(JPEG_IOCTL_SET_ENCODE_MODE, JPEG_ENC_SOURCE_PLANAR, JPEG_ENC_PRIMARY_YUV420);	
        	    		    
	    /* Primary Encode Image Width / Height */    
	jpegIoctl(JPEG_IOCTL_SET_DIMENSION, u16Height, u16Width);	       
	
   	        //Set Encode Source Image Height        
	jpegIoctl(JPEG_IOCTL_SET_SOURCE_IMAGE_HEIGHT, u16Height, 0);
 
		/* 	Include Quantization-Table and Huffman-Table */	
	jpegIoctl(JPEG_IOCTL_ENC_SET_HEADER_CONTROL, JPEG_ENC_PRIMARY_QTAB | JPEG_ENC_PRIMARY_HTAB, 0);
  
	       
		/* Use the default Quantization-table 0, Quantization-table 1 */
	//jpegIoctl(JPEG_IOCTL_SET_DEFAULT_QTAB, 0, 0);
#if 0		
        jpegAdjustUserQTAB(g_au8QTableStd0, g_au8QTableUser0, 75);
        jpegAdjustUserQTAB(g_au8QTableStd1, g_au8QTableUser1, 75);
#endif
	jpegSetQTAB(g_au8QTableUser0,g_au8QTableUser1, 0, 2);
	
	/* Trigger JPEG encoder */
	jpegIoctl(JPEG_IOCTL_ENCODE_TRIGGER, 0, 0);  
	    
	    /* Wait for complete */
    	return 0;
    	
}

/* JPEG Encode function */
void jpegPre()
{

        jpegAdjustUserQTAB(g_au8QTableStd0, g_au8QTableUser0, 60);
        jpegAdjustUserQTAB(g_au8QTableStd1, g_au8QTableUser1, 60);
		
}
