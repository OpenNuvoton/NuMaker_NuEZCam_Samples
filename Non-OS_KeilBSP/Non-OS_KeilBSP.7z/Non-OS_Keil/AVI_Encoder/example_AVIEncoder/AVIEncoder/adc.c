/****************************************************************************
*                                                                           *
* Copyright (c) 2009 Nuvoton Tech. Corp. All rights reserved.               *
*                                                                           *
*****************************************************************************/

/****************************************************************************
* FILENAME
*   adc.c
*
* VERSION
*   1.0
*
* DESCRIPTION
*   ADC sample application using ADC library
*
* DATA STRUCTURES
*   None
*
* FUNCTIONS
*
* HISTORY
*
* REMARK
*   None
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "wblib.h"
#include "W55FA93_adc.h"
//#include "nvtfat.h"
#include "DrvEDMA.h"

int InitializeUAC(UINT32 u32SampleRate);
void StartUAC(void);
void StopUAC(void);
int GetPCMSampleData(PINT16 pi16PCM, INT32 i32SampleCount);


#define UAC_MUTE_ADDR		0

#define E_AUD_BUF  16*100/2  // 640 bytes --> 32*10 for 16KHz, 10 ms samples
#define TRAN_SAMPLE  4*100/2   // 640/2 = 320 bytes, for half, 320 bytes = 2 x 160, 160 samples --> 10 msec samples

//#define IN_DATA_BUF_NUM  128*10*4*2
int IN_DATA_BUF_NUM;


//static volatile INT8 g_i8PcmReady = FALSE;
__align(32) INT16 g_pi16SampleBuf[E_AUD_BUF/2];		/* Keep max 16K sample rate */
//__align(32) INT16 g_pi16AudioBuf[E_AUD_BUF/2*4*4];
INT16 *g_pi16AudioBuf;



UINT8 bPlaying = FALSE;

volatile INT32  s_i16RecOutPos;
volatile INT32  s_i16RecInPos;   
volatile INT32 s_i16RecInSample;


// recorder
/*
__align(4) INT32 g_i32RecorderAttr[5] = {
0,        // mute off
FU_VOLUME_CUR,    //2560,     // current volume,
FU_VOLUME_MIN,      //-32768,   // min
FU_VOLUME_MAX,     // 32768,    // max
1 	  // res 	
};	
*/
//INT16 i16TestNo;				
static void pfnRecordCallback(void)
{
//	g_i8PcmReady = TRUE;
}

//volatile BOOL bIsBufferDone=0;
void edmaCallback(UINT32 u32WrapStatus)
{
	UINT32 u32Period, u32Attack, u32Recovery, u32Hold;
    INT16 *pi16srcADC;
    UINT32 i;

	if(u32WrapStatus==256)
	{
//		bIsBufferDone = 1;
//		sysprintf("I %d\n\n", bIsBufferDone);
		if ( bPlaying == TRUE )	
		{
//		sysprintf("I 256\n");		
            pi16srcADC = (INT16 *)(((UINT32)g_pi16SampleBuf+E_AUD_BUF/2) | 0x80000000);  			        
			for (i= 0; i< TRAN_SAMPLE; i++)
	        {
				g_pi16AudioBuf[s_i16RecInPos++]= *pi16srcADC++;
//				g_pi16AudioBuf[s_i16RecInPos++]= i16TestNo++;
			}	
 			if (s_i16RecInPos ==  IN_DATA_BUF_NUM)
   			{
				s_i16RecInPos = 0;
			}		
			s_i16RecInSample += TRAN_SAMPLE;
        }
	}	
	else if(u32WrapStatus==1024)
	{
		
//		bIsBufferDone = 2;		
//		sysprintf("I %d\n\n", bIsBufferDone);
		if ( bPlaying == TRUE )	
		{
//		sysprintf("I 1024\n");		
            pi16srcADC = (INT16 *)(((UINT32)g_pi16SampleBuf) | 0x80000000) ;
			for (i= 0; i< TRAN_SAMPLE; i++)
            {
				g_pi16AudioBuf[s_i16RecInPos++]= *pi16srcADC++;
//				g_pi16AudioBuf[s_i16RecInPos++]= i16TestNo++;						
			}	
 			if (s_i16RecInPos ==  IN_DATA_BUF_NUM)
   			{
				s_i16RecInPos = 0;
			}		
			s_i16RecInSample += TRAN_SAMPLE;
		}
	}
	/* AGC response speed */
	ADC_GetAutoGainTiming(&u32Period, &u32Attack, &u32Recovery, &u32Hold);
	if(u32Period<128)
	{		
		u32Period = u32Period+16;
		ADC_SetAutoGainTiming(u32Period, u32Attack, u32Recovery, u32Hold);		
	}

}
/*
	The EDMA will move audio data to start address = g_pi16SampleBuf[0] with range u32Length. 
	The EDMA will issue interrupt in data reach to half of u32Length and u32Length. 	
	Then repeat to filled audio data to  g_pi16SampleBuf[0].
	Programmer must write audio data ASAP. 
*/
void InitEDMA(UINT32 u32Length)
{
	S_DRVEDMA_CH_ADDR_SETTING pSrc, pDest;
	PFN_DRVEDMA_CALLBACK *pfnOldcallback;  
	
	pSrc.u32Addr = REG_AUDIO_BUF0;
	pSrc.eAddrDirection = eDRVEDMA_DIRECTION_FIXED;
	pDest.u32Addr = (unsigned int)g_pi16SampleBuf | 0x80000000;
	pDest.eAddrDirection = eDRVEDMA_DIRECTION_WRAPAROUND;
	DrvEDMA_Open();

	DrvEDMA_EnableCH(eDRVEDMA_CHANNEL_1,eDRVEDMA_ENABLE);
	DrvEDMA_SetAPBTransferWidth(eDRVEDMA_CHANNEL_1,eDRVEDMA_WIDTH_16BITS);	// Mode 0 : 16 Bit
	DrvEDMA_SetCHForAPBDevice(eDRVEDMA_CHANNEL_1, eDRVEDMA_ADC, eDRVEDMA_READ_APB);
	DrvEDMA_SetTransferSetting(eDRVEDMA_CHANNEL_1, &pSrc, &pDest, u32Length); //16K
	DrvEDMA_SetWrapIntType(eDRVEDMA_CHANNEL_1,eDRVEDMA_WRAPAROUND_HALF | eDRVEDMA_WRAPAROUND_EMPTY);
	DrvEDMA_EnableInt(eDRVEDMA_CHANNEL_1,eDRVEDMA_WAR);	
	
	DrvEDMA_InstallCallBack(eDRVEDMA_CHANNEL_1, 
						eDRVEDMA_WAR,
						edmaCallback,
						pfnOldcallback);	
	
}	

//	u32SampleRate = 16000;	
int InitializeUAC(UINT32 u32SampleRate)
{	
	
	PFN_ADC_CALLBACK 	pfnOldCallback;
	
	outp32(REG_APLLCON, 0x12A7);
	
	audio_Open(eSYS_APLL, u32SampleRate);
	adc_disableInt(eADC_AUD_INT);
	adc_installCallback(eADC_AUD_INT,
					pfnRecordCallback,	/* Invalid if EDMA enable */
					&pfnOldCallback);
		
	return 0;
}

void StartUAC(void)
{	
//	bPlaying = TRUE;
	s_i16RecOutPos = s_i16RecInPos = 0;   
	s_i16RecInSample = 0;
	InitEDMA(E_AUD_BUF);	
	adc_StartRecord(); 
	DrvEDMA_CHEnablelTransfer(eDRVEDMA_CHANNEL_1);
//	i16TestNo = 0;
}

void StopUAC(void)
{
	bPlaying = FALSE;
	adc_disableInt(eADC_AUD_INT);
	DrvEDMA_Close();
	adc_StopRecord();

	s_i16RecOutPos = s_i16RecInPos = 0; 
	s_i16RecInSample = 0;
	
}

/* get data to  */	  
int GetPCMSampleData(PINT16 pi16PCM, INT32 i32SampleCount)
{
	PINT16 pi16Buf;
	int i, rem, ano;

   	if (s_i16RecInSample < i32SampleCount )
        	return 0 ;
   	
   	pi16Buf = &g_pi16AudioBuf[s_i16RecOutPos];
	if ( s_i16RecOutPos + i32SampleCount >= IN_DATA_BUF_NUM)
	{
	    rem = IN_DATA_BUF_NUM - s_i16RecOutPos;
	    for (i=0; i< rem; i++)
	    {
     	   *pi16PCM++ = *pi16Buf++;      
	    }
        ano = i32SampleCount - rem;
        if ( ano != 0 )
        {
	    	pi16Buf = &g_pi16AudioBuf[0];
    		for (i=0; i< ano; i++)
	    	{
	     	   *pi16PCM++ = *pi16Buf++ ;      
		    }        	    
	    }
   	    s_i16RecOutPos  = ano;
 	}
	else
	{
	    for (i=0; i< i32SampleCount; i++)
	    {
    	   *pi16PCM++ = *pi16Buf++;
	    }
	    s_i16RecOutPos += i32SampleCount;
	}	
    s_i16RecInSample -= i32SampleCount;	
    return i32SampleCount; 
}  
 

