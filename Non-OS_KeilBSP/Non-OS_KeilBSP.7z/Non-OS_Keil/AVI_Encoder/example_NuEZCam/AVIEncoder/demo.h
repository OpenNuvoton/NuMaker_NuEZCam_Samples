#ifndef _VIDEOIN_DEMO
#define _VIDEOIN_DEMO

//#define ARDUINO				1  
#define SMALL_BOARD		1

#define UART_NORMAL		1
#define UART_HIGHSPEED	2

	
#define ENCODE_BUFFERNO 	2
#define JPEG_BUFFERNO		20      //15
#define MAX_JPEG_SIZE		0x1C000 //0xC800

#define AVI_ENCODER			1
#define USB_UVC_UAC			3
#define USB_MSC					2
#define USB_UVC					4

#define OPT_UART
#ifdef OPT_UART
#define DBG_PRINTF		sysprintf
#else
#define DBG_PRINTF		printf
#endif

#if 0
#ifdef QVGA
#define OPT_STRIDE		320  
#define OPT_CROP_WIDTH		640 
#define OPT_CROP_HEIGHT		480   
#define OPT_PREVIEW_WIDTH		320 
#define OPT_PREVIEW_HEIGHT		240  

#define OPT_ENCODE_WIDTH   320
#define OPT_ENCODE_HEIGHT  240
#endif

#ifdef X480X272
#define OPT_STRIDE		480  
#define OPT_CROP_WIDTH		480 
#define OPT_CROP_HEIGHT		272   
#define OPT_PREVIEW_WIDTH		480 
#define OPT_PREVIEW_HEIGHT		272  

#define OPT_ENCODE_WIDTH   480
#endif

//#ifdef VGA
#define OPT_STRIDE		320  
#define OPT_CROP_WIDTH		640 
#define OPT_CROP_HEIGHT		480   
#define OPT_PREVIEW_WIDTH		320 
#define OPT_PREVIEW_HEIGHT		240  

#define OPT_ENCODE_WIDTH   	320
#define OPT_ENCODE_HEIGHT   240
//#endif
#endif

extern int  OPT_STRIDE;		  
extern int  OPT_CROP_WIDTH;		 
extern int  OPT_CROP_HEIGHT;		   
extern int  OPT_PREVIEW_WIDTH;		 
extern int  OPT_PREVIEW_HEIGHT;	  

extern int  OPT_ENCODE_WIDTH;   	
extern int  OPT_ENCODE_HEIGHT;   

// current sensor definition
#define OV_7670			3
#define OV_7725			4
void VideoIn_InterruptHandler(void);

#define BITSTREAM_OFFSET 64*1024

//GCD.c
UINT8 GCD(UINT16 m1, UINT16 m2);

typedef struct{
	INT32 (*IQ_GetBrightness)(void);
	INT32 (*IQ_SetBrightness)(INT16);
	INT32 (*IQ_GetSharpness)(void);	
	INT32 (*IQ_SetSharpness)(INT16);	
	INT32 (*IQ_GetContrast)(void);	
	INT32 (*IQ_SetContrast)(INT16);	
	INT32 (*IQ_GetHue)(void);
	INT32 (*IQ_SetHue)(INT16);	
}IQ_S;
//Smpl_OV9660.c
UINT32 Smpl_OV9660(UINT8* pu8FrameBuffer0, UINT8* pu8FrameBuffer1);
UINT32 Smpl_OV7670(UINT8* pu8FrameBuffer0, UINT8* pu8FrameBuffer1);
UINT32 Smpl_OV7725(UINT8* pu8FrameBuffer0, UINT8* pu8FrameBuffer1);
UINT32 Smpl_WT8861(UINT8* pu8FrameBufferid);
UINT32 Smpl_NT99050(UINT8* pu8FrameBuffer0, UINT8* pu8FrameBuffer1);
UINT32 Smpl_NT99141_HD(UINT8* pu8FrameBuffer0, UINT8* pu8FrameBuffer1);
UINT32 Smpl_GC0308(UINT8* pu8FrameBuffer0, UINT8* pu8FrameBuffer1);

INT32 register_sensor(IQ_S* ps_sensor);
/* Buffer for Packet & Planar format */
extern volatile UINT32 u32PacketFrameBuffer0,u32BitstreamBuffer0, u32PacketFrameBuffer1;
extern UINT8  u8FrameBuffer0[];	
extern UINT8  u8FrameBuffer1[];	
extern UINT8  u8BitstreamBuffer0[];
//extern UINT32	u8BitstreamBuffer0;


/* Current Width & Height */
extern UINT16 u16CurWidth, u16CurHeight;

void Delay(UINT32 nCount);

/* AVI Encoder Main */
void AVIEnc_main(void);
void uavc_main(void);
/* UVC event */
void VideoInFrameEnd_InterruptHandler(void);
/* Get Image Buffer for USB transfer */
/* JPEG Encode function */
UINT32 jpegEncode(UINT32 u32YAddress,UINT32 u32BitstreamAddress, UINT16 u16Width,UINT16 u16Height);
/* Process Unit Control */
void uvc_main(void);

//Smpl_I2C.C
BOOL 
I2C_Write_8bitSlaveAddr_8bitReg_8bitData(
	UINT8 uAddr, 
	UINT8 uRegAddr, 
	UINT8 uData	
);
UINT8 
I2C_Read_8bitSlaveAddr_8bitReg_8bitData(
	UINT8 uAddr, 
	UINT8 uRegAddr
);

#endif /* !_VIDEOIN_DEMO */
