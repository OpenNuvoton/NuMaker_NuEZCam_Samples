#include "wblib.h"
#include "W55FA93_VideoIn.h"
#include "W55FA93_GPIO.h"
#include "DrvI2C.h"
#include "demo.h"

typedef struct
{
	UINT32 u32Width;
	UINT32 u32Height;
	char* pszFileName;
}S_VIDEOIN_REAL;
typedef struct
{
	UINT32 u32Width;
	UINT32 u32Height;
	E_VIDEOIN_OUT_FORMAT eFormat;
	char* pszFileName;
}S_VIDEOIN_PACKET_FMT;

struct OV_RegValue
{
	UINT8	u8RegAddr;		//Register Address
	UINT8	u8Value;			//Register Data
};

struct OV_RegTable{
	struct OV_RegValue *sRegTable;
	UINT32 u32TableSize;
};

//#define UDC
#define AEC_MEASURE_WINDOW_X0_DAY       40/4
#define AEC_MEASURE_WINDOW_Y0_DAY       40/4
#define AEC_MEASURE_WINDOW_WIDTH_DAY    560/4
#define AEC_MEASURE_WINDOW_HEIGHT_DAY   400/4

#define AEC_MEASURE_AREA_WIDTH          160
#define AEC_MEASURE_AREA_HEIGHT         120
#define AEC_MEASURE_WINDOW_WIDTH        AEC_MEASURE_AREA_WIDTH/4
#define AEC_MEASURE_WINDOW_HEIGHT       AEC_MEASURE_AREA_HEIGHT/4
#define AEC_MEASURE_WINDOW_X0           ((640-AEC_MEASURE_AREA_WIDTH)/2)/4   // 0x12
#define AEC_MEASURE_WINDOW_Y0           ((480-AEC_MEASURE_AREA_HEIGHT)/2)/4   // 0x0A

#define GLB_SATURATE                    0x50    // 0x40
#define CB_SATURATE                     0x40
#define CR_SATURATE                     0x40
#define DAY_MODE_LUMA_CONTRAST          0x30    // 0x44
#define NIGHT_MODE_LUMA_CONTRAST        0x44

#define DAY_MODE_CONTRAST_CENTER        0xB0    // 0x80
#define NIGHT_MODE_CONTRAST_CENTER      0x80

#define SHARP_DAY		        0x06    // 0x36
#define SHARP_NIGHT		        0x76

#define DAY_MODE_GLOBAL_GAIN            0x22    // 0x33   // 0x22   // 0x14
#define NIGHT_MODE_GLOBAL_GAIN          0x30    // 0x10   // 0x33   // 0x22   // 0x14

#define DAY_MODE_EXP_H                  0x06    // 0x05    //0x03	// 0x02
#define DAY_MODE_EXP_L                  0xDC    //0x84	// 0xEE

#define NIGHT_MODE_EXP_H                0x0E    // 0x0D   // 0x0A	// 0x0A 
#define NIGHT_MODE_EXP_L                0x80    // 0x00	// 0x41

#define REG15_VGA                       0x0A
#define REG15_CIF                       0x8A
#define REG24_RGB_565                   0xA6
#define REG24_YUV_422                   0xA2


#define ___60HZ__
//#define ___50HZ__
#ifdef ___60HZ__
#define DAY_MODE_EXP_H    0x06
#define DAY_MODE_EXP_L    0xDC
#else
#define DAY_MODE_EXP_H    0x04//  0x06    // 0x05    //0x03 // 0x02
#define DAY_MODE_EXP_L    0xB0//  0xDC    //0x84 // 0xEE
#endif


extern UINT8 u8PlanarFrameBuffer[];

extern int g_iTarget;


#define _REG_TABLE_SIZE(nTableName)	(sizeof(nTableName)/sizeof(struct OV_RegValue))

struct OV_RegValue g_sGC0308_RegValue[] = 
{
	#include "GC0308\GC0308_VGA.dat"
};

static struct OV_RegTable g_OV_InitTable[] =
{//8 bit slave address, 8 bit data. 
	{0, 0},
	{0, 0},//{g_sOV6880_RegValue,	_REG_TABLE_SIZE(g_sOV6880_RegValue)},		
	{0, 0},//{g_sOV7648_RegValue,	_REG_TABLE_SIZE(g_sOV7648_RegValue)},
	{0, 0},//{g_sOV7670_RegValue,	_REG_TABLE_SIZE(g_sOV7670_RegValue)},
	{0, 0},//{g_sOV7725_RegValue,	_REG_TABLE_SIZE(g_sOV7725_RegValue)},	
	{0, 0},//{g_sOV2640_RegValue,	_REG_TABLE_SIZE(g_sOV2640_RegValue)},	
	{0, 0},//{g_sOV9660_RegValue,	_REG_TABLE_SIZE(g_sOV9660_RegValue)},
	{g_sGC0308_RegValue,	_REG_TABLE_SIZE(g_sGC0308_RegValue)},
	{0, 0}
};

static UINT8 g_uOvDeviceID[]= 
{
	0x00,		// not a device ID
	0xc0,		// ov6680
	0x42,		// ov7648
	0x42,		// ov7670
	0x42,		// ov7725
	0x60,		// ov2640
	0x60,		// 0v9660
	0x42,		// GC0308
	0x00		// not a device ID
};


/*
	Sensor power down and reset may default control on sensor daughter board.
	Reset by RC.
	Sensor alway power on (Keep low)

*/
static void SnrReset(void)
{
#ifndef SMALL_BOARD
/* GPB02 reset:	H->L->H 	*/				
	//gpio_open(GPIO_PORTB);					//GPIOB2 as GPIO		
	outp32(REG_GPBFUN, inp32(REG_GPBFUN) & (~MF_GPB2));
	
	gpio_setportval(GPIO_PORTB, 1<<2, 1<<2);	//GPIOB 2 set high default
	gpio_setportpull(GPIO_PORTB, 1<<2, 1<<2);	//GPIOB 2 pull-up 
	gpio_setportdir(GPIO_PORTB, 1<<2, 1<<2);	//GPIOB 2 output mode 
	Delay(1000);			
	gpio_setportval(GPIO_PORTB, 1<<2, 0<<2);	//GPIOB 2 set low
	Delay(1000);				
	gpio_setportval(GPIO_PORTB, 1<<2, 1<<2);	//GPIOb 2 set high
#else	
	outp32(REG_GPBFUN, inp32(REG_GPBFUN) & (~MF_GPB4));
	
	gpio_setportval(GPIO_PORTB, 1<<4, 1<<4);	//GPIOB 4 set high default
	gpio_setportpull(GPIO_PORTB, 1<<4, 1<<4);	//GPIOB 4 pull-up 
	gpio_setportdir(GPIO_PORTB, 1<<4, 1<<4);	//GPIOB 4 output mode 
	Delay(1000);			
	gpio_setportval(GPIO_PORTB, 1<<4, 0<<4);	//GPIOB 4 set low
	Delay(1000);				
	gpio_setportval(GPIO_PORTB, 1<<4, 1<<4);	//GPIOb 4 set high
#endif
}

static void SnrPowerDown(BOOL bIsEnable)
{/* GPB3 power down, HIGH for power down */
#ifdef SMALL_BOARD
	outp32(REG_GPBFUN, inp32(REG_GPBFUN) & (~MF_GPB5));
	
	gpio_setportval(GPIO_PORTB, 1<<5, 1<<5);		//GPIOB 5 set high default
	gpio_setportpull(GPIO_PORTB, 1<<5, 1<<5);		//GPIOB 5 pull-up 
	gpio_setportdir(GPIO_PORTB, 1<<5, 1<<5);		//GPIOB 5 output mode 				
	if(bIsEnable)
		gpio_setportval(GPIO_PORTB, 1<<5, 1<<5);	//GPIOB 5 set high
	else				
		gpio_setportval(GPIO_PORTB, 1<<5, 0);	
#else
	//gpio_open(GPIO_PORTB);						//GPIOB as GPIO
	outp32(REG_GPBFUN, inp32(REG_GPBFUN) & (~MF_GPB3));
	
	gpio_setportval(GPIO_PORTB, 1<<3, 1<<3);		//GPIOB 3 set high default
	gpio_setportpull(GPIO_PORTB, 1<<3, 1<<3);		//GPIOB 3 pull-up 
	gpio_setportdir(GPIO_PORTB, 1<<3, 1<<3);		//GPIOB 3 output mode 				
	if(bIsEnable)
		gpio_setportval(GPIO_PORTB, 1<<3, 1<<3);	//GPIOB 3 set high
	else				
		gpio_setportval(GPIO_PORTB, 1<<3, 0);		//GPIOB 3 set low
#endif		
}


BOOL GC0308_Init(UINT32 nIndex)
{
	UINT32 u32Idx;
	UINT32 u32TableSize;
	UINT8  u8DeviceID;
	UINT8 u8ID;
	struct OV_RegValue *psRegValue;
	DBG_PRINTF("Sensor ID = %d\n", nIndex);
	if ( nIndex >= (sizeof(g_uOvDeviceID)/sizeof(UINT8)) )
		return FALSE;
//	videoIn_Open(48000, 24000);								/* For sensor clock output */	
#ifndef SMALL_BOARD
	SnrPowerDown(FALSE);
#endif	
	SnrReset();	
#ifdef SMALL_BOARD
	SnrPowerDown(FALSE);
#endif		  	 											
	
	u32TableSize = g_OV_InitTable[nIndex].u32TableSize;
	psRegValue = g_OV_InitTable[nIndex].sRegTable;
	u8DeviceID = g_uOvDeviceID[nIndex];
	DBG_PRINTF("Device Slave Addr = 0x%x\n", u8DeviceID);
// mask by inchu for I2C read sequence can progressive
//	if ( psRegValue == 0 )
//		return;	
#ifndef SMALL_BOARD
	outp32(REG_GPBFUN, inp32(REG_GPBFUN) & (~MF_GPB13));
	outp32(REG_GPBFUN, inp32(REG_GPBFUN) & (~MF_GPB14));
	DrvI2C_Open(eDRVGPIO_GPIOB, 					
				eDRVGPIO_PIN13, 
				eDRVGPIO_GPIOB,
				eDRVGPIO_PIN14, 
				(PFN_DRVI2C_TIMEDELY)Delay);
#else
	outp32(REG_GPAFUN, inp32(REG_GPAFUN) & (~MF_GPA3));
	outp32(REG_GPAFUN, inp32(REG_GPAFUN) & (~MF_GPA4));
	DrvI2C_Open(eDRVGPIO_GPIOA, 					
				eDRVGPIO_PIN3, 
				eDRVGPIO_GPIOA,
				eDRVGPIO_PIN4, 
				(PFN_DRVI2C_TIMEDELY)Delay);

#endif

									
	for(u32Idx=0;u32Idx<u32TableSize; u32Idx++, psRegValue++)
	{
		if ( I2C_Write_8bitSlaveAddr_8bitReg_8bitData(u8DeviceID, (psRegValue->u8RegAddr), (psRegValue->u8Value)) == FALSE)	
			return FALSE;
		if ((psRegValue->u8RegAddr)==0x12 && (psRegValue->u8Value)==0x80)
		{	
			Delay(1000);		
			DBG_PRINTF("Delay A loop\n");
		}				
	}
	u8ID = I2C_Read_8bitSlaveAddr_8bitReg_8bitData(u8DeviceID, 0x0A);
//	if ( u8ID != 0xE8 )
//		return FALSE;
	DBG_PRINTF("Sensor ID0 = 0x%x\n", u8ID);
	u8ID = I2C_Read_8bitSlaveAddr_8bitReg_8bitData(u8DeviceID, 0x0B);
	DBG_PRINTF("Sensor ID0 = 0x%x\n", u8ID);
	u8ID = I2C_Read_8bitSlaveAddr_8bitReg_8bitData(u8DeviceID, 0x1C);
	DBG_PRINTF("Sensor ID0 = 0x%x\n", u8ID);
	u8ID = I2C_Read_8bitSlaveAddr_8bitReg_8bitData(u8DeviceID, 0x1D);
	DBG_PRINTF("Sensor ID0 = 0x%x\n", u8ID);

	u8ID = I2C_Read_8bitSlaveAddr_8bitReg_8bitData(u8DeviceID, 0xD7);
	DBG_PRINTF("Sensor ID0 = 0x%x\n", u8ID);
	u8ID = I2C_Read_8bitSlaveAddr_8bitReg_8bitData(u8DeviceID, 0x6A);	
	DBG_PRINTF("Sensor ID0 = 0x%x\n", u8ID);
	
	DrvI2C_Close();	
	return TRUE;
}


/*===================================================================
	LCD dimension = (OPT_LCD_WIDTH, OPT_LCD_HEIGHT)	
	Packet dimension = (OPT_PREVIEW_WIDTH*OPT_PREVIEW_HEIGHT)	
	Stride should be LCM resolution  OPT_LCD_WIDTH.
	Packet frame start address = VPOST frame start address + (OPT_LCD_WIDTH-OPT_PREVIEW_WIDTH)/2*2 	
=====================================================================*/
UINT32 Smpl_GC0308(UINT8* pu8FrameBuffer0, UINT8* pu8FrameBuffer1)
{
	PFN_VIDEOIN_CALLBACK pfnOldCallback;
	UINT32 u32GCD;

#ifdef SMALL_BOARD
	videoIn_Init(TRUE, (E_VIDEOIN_SNR_SRC)0, 24000, eVIDEOIN_2ND_SNR_CCIR601);	
#else	
		// GPIOD2 pull high
		gpio_setportval(GPIO_PORTD, 0x04, 0x04);    //GPIOD2 high to enable Amplifier 
		gpio_setportpull(GPIO_PORTD, 0x04, 0x04);	//GPIOD2 pull high
		gpio_setportdir(GPIO_PORTD, 0x04, 0x04);	//GPIOD2 output mode
		videoIn_Init(TRUE, (E_VIDEOIN_SNR_SRC)0, 24000, eVIDEOIN_3RD_SNR_CCIR601);		
#endif 
	
	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | HCLK4_CKE);
	
#if 0	
#ifdef __1ST_PORT__	
	videoIn_Init(TRUE, 0, 24000, eVIDEOIN_SNR_CCIR601);
#endif
#ifdef __2ND_PORT__
	videoIn_Init(TRUE, 0, 24000, eVIDEOIN_2ND_SNR_CCIR601);	
#endif	
#ifdef __3RD_PORT__
	videoIn_Init(TRUE, 0, 24000, eVIDEOIN_3RD_SNR_CCIR601);	
#endif
#endif

//	outp32(REG_AHBCLK, inp32(REG_AHBCLK) | HCLK4_CKE);
	
	if ( GC0308_Init(7) == FALSE )
		return Fail;	
			
	videoIn_Open(48000, 24000);		
	videoIn_EnableInt(eVIDEOIN_VINT);
	
	videoIn_InstallCallback(eVIDEOIN_VINT, 
						(PFN_VIDEOIN_CALLBACK)VideoIn_InterruptHandler,
						&pfnOldCallback	);	//Frame End interrupt
						
	videoIn_SetPacketFrameBufferControl(FALSE, FALSE);	
	
	videoinIoctl(VIDEOIN_IOCTL_SET_POLARITY,
				FALSE,
				TRUE,							//Polarity.	
				TRUE);							
												
	videoinIoctl(VIDEOIN_IOCTL_ORDER_INFMT_OUTFMT,								
				eVIDEOIN_IN_UYVY, 			//Input Order 
				eVIDEOIN_IN_YUV422,		//Intput format//eVIDEOIN_IN_YUV422,		//Intput format
				eVIDEOIN_OUT_YUV422);		//Output format for packet 														
		
	videoinIoctl(VIDEOIN_IOCTL_SET_CROPPING_START_POSITION,				
				0,							//Vertical start position
				0,							//Horizontal start position	
				0);							//Useless
	videoinIoctl(VIDEOIN_IOCTL_CROPPING_DIMENSION,				
				OPT_CROP_HEIGHT,							//UINT16 u16Height, 
				OPT_CROP_WIDTH,							//UINT16 u16Width;	
				0);							//Useless
#if 0	
	if (g_iTarget == AVI_ENCODER )
	{				
	/* Set Planar dimension  */					
	u32GCD = GCD(OPT_ENCODE_HEIGHT, OPT_CROP_HEIGHT);						 							 
	videoinIoctl(VIDEOIN_IOCTL_VSCALE_FACTOR,
				eVIDEOIN_PLANAR,			//640/640
				OPT_ENCODE_HEIGHT/u32GCD,
				OPT_CROP_HEIGHT/u32GCD);		
	u32GCD = GCD(OPT_ENCODE_WIDTH, OPT_CROP_WIDTH);																
	videoinIoctl(VIDEOIN_IOCTL_HSCALE_FACTOR,
				eVIDEOIN_PLANAR,			//640/640
				OPT_ENCODE_WIDTH/u32GCD,
				OPT_CROP_WIDTH/u32GCD);
				
	videoinIoctl(VIDEOIN_IOCTL_SET_STRIDE,										
				OPT_STRIDE,				
				OPT_ENCODE_WIDTH,
				0);
	
								
	/* Set Planar Buffer Address */						
	videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,				
				0, 							//0 = Planar Y buffer address
				(UINT32)pu8FrameBuffer0 );							
	videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				1, 							//1 = Planar U buffer address
				(UINT32)pu8FrameBuffer0+ OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT);							
	videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PLANAR,			
				2, 							//2 = Planar V buffer address
				(UINT32)pu8FrameBuffer0 +  OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT+OPT_ENCODE_WIDTH*OPT_ENCODE_HEIGHT/4 );							
	
	videoinIoctl(VIDEOIN_IOCTL_SET_PIPE_ENABLE,
				TRUE, 						// Engine enable ?
				eVIDEOIN_PLANAR,		// which pipes was enable. 											
				0 );							//Useless		
	outp32(REG_VPEPAR, (inp32(REG_VPEPAR) & ~PNFMT) |PNFMT);		
	}
	else
#endif		
	{
	/* Set Packet dimension */
#if 0		
	u32GCD = GCD(OPT_PREVIEW_HEIGHT, OPT_CROP_HEIGHT);						 							 
	videoinIoctl(VIDEOIN_IOCTL_VSCALE_FACTOR,
				eVIDEOIN_PACKET,			//272/480
				OPT_PREVIEW_HEIGHT/u32GCD,
				OPT_CROP_HEIGHT/u32GCD);		
	u32GCD = GCD(OPT_PREVIEW_WIDTH, OPT_CROP_WIDTH);																
	videoinIoctl(VIDEOIN_IOCTL_HSCALE_FACTOR,
				eVIDEOIN_PACKET,			//364/640
				OPT_PREVIEW_WIDTH/u32GCD,
				OPT_CROP_WIDTH/u32GCD);	
#endif
	u32GCD = GCD(OPT_ENCODE_HEIGHT, OPT_CROP_HEIGHT);						 							 
	videoinIoctl(VIDEOIN_IOCTL_VSCALE_FACTOR,
				eVIDEOIN_PACKET,			//640/640
				OPT_ENCODE_HEIGHT/u32GCD,
				OPT_CROP_HEIGHT/u32GCD);		
	u32GCD = GCD(OPT_ENCODE_WIDTH, OPT_CROP_WIDTH);																
	videoinIoctl(VIDEOIN_IOCTL_HSCALE_FACTOR,
				eVIDEOIN_PACKET,			//640/640
				OPT_ENCODE_WIDTH/u32GCD,
				OPT_CROP_WIDTH/u32GCD);
		
	/* Set Pipes stride */				
	videoinIoctl(VIDEOIN_IOCTL_SET_STRIDE,										
				OPT_STRIDE,				
				OPT_ENCODE_WIDTH,
				0);
									
	/* Set Packet Buffer Address */						
	videoinIoctl(VIDEOIN_IOCTL_SET_BUF_ADDR,
				eVIDEOIN_PACKET,			
				0, 							//Packet buffer addrress 0	
				(UINT32)((UINT32)pu8FrameBuffer0) );			

	videoinIoctl(VIDEOIN_IOCTL_SET_PIPE_ENABLE,
				TRUE, 						// Engine enable ?
				eVIDEOIN_PACKET,			// which packet was enable. 											
				0 );											
	}				
									
	sysSetLocalInterrupt(ENABLE_IRQ);		
	
	
					
														
	return Successful;			
}	
